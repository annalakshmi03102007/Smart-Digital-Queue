import threading

import database
from services import notification_service as notes
from services import queue_service as queue
from tests.base import BaseTestCase


class TokenGenerationTests(BaseTestCase):
    def test_book_token_creates_waiting_token_and_notification(self):
        (u,) = self.make_users(1)
        tid = queue.book_token(self.conn, u, self.gen)
        token = queue.get_token(self.conn, tid)
        self.assertEqual(token["token_number"], 1)
        self.assertEqual(token["status"], "waiting")
        self.assertEqual(queue.label_of(token), "GEN-001")
        self.assertEqual(token["service_date"], queue.today())
        self.assertEqual(notes.unread_count(self.conn, u), 1)

    def test_numbers_are_sequential_per_department_and_day(self):
        u1, u2, u3, u4 = self.make_users(4)
        nums = [queue.get_token(self.conn, queue.book_token(self.conn, u, self.gen))["token_number"]
                for u in (u1, u2, u3)]
        self.assertEqual(nums, [1, 2, 3])
        # another department starts again from 1
        self.assertEqual(queue.get_token(self.conn, queue.book_token(self.conn, u4, self.bil))["token_number"], 1)
        # another service day starts again from 1
        other = queue.get_token(self.conn, queue.book_token(self.conn, u1, self.gen, service_date="2030-01-01",
                                                            allow_multiple=True))
        self.assertEqual(other["token_number"], 1)

    def test_cancelled_numbers_are_not_reused(self):
        u1, u2 = self.make_users(2)
        t1 = queue.book_token(self.conn, u1, self.gen)
        queue.cancel_by_user(self.conn, t1, u1)
        t2 = queue.get_token(self.conn, queue.book_token(self.conn, u2, self.gen))
        self.assertEqual(t2["token_number"], 2)

    def test_duplicate_active_token_blocked(self):
        (u,) = self.make_users(1)
        queue.book_token(self.conn, u, self.gen)
        with self.assertRaises(queue.QueueError) as ctx:
            queue.book_token(self.conn, u, self.bil)
        self.assertIn("already have an active token", str(ctx.exception))
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM tokens").fetchone()[0], 1)

    def test_duplicate_allowed_when_explicitly_enabled(self):
        (u,) = self.make_users(1)
        queue.book_token(self.conn, u, self.gen, allow_multiple=True)
        queue.book_token(self.conn, u, self.bil, allow_multiple=True)
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM tokens").fetchone()[0], 2)

    def test_new_token_allowed_after_previous_is_finished(self):
        (u,) = self.make_users(1)
        t = queue.book_token(self.conn, u, self.gen)
        queue.cancel_by_user(self.conn, t, u)
        queue.book_token(self.conn, u, self.gen)      # no error

    def test_inactive_or_missing_department_rejected(self):
        (u,) = self.make_users(1)
        off = self.make_department("Closed", "CLS", 5, active=0)
        for dept in (off, 9999):
            with self.assertRaises(queue.QueueError):
                queue.book_token(self.conn, u, dept)

    def test_concurrent_booking_never_duplicates_numbers(self):
        users = self.make_users(12)
        errors = []

        def worker(user_id):
            conn = database.connect(self.db_path)
            try:
                queue.book_token(conn, user_id, self.gen)
            except Exception as exc:                 # noqa: BLE001
                errors.append(exc)
            finally:
                conn.close()

        threads = [threading.Thread(target=worker, args=(u,)) for u in users]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.assertEqual(errors, [])
        numbers = sorted(r[0] for r in self.conn.execute("SELECT token_number FROM tokens"))
        self.assertEqual(numbers, list(range(1, 13)))


class QueuePositionTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.users = self.make_users(4)
        self.tokens = [queue.book_token(self.conn, u, self.gen) for u in self.users]   # avg 5 min

    def info(self, index):
        return queue.queue_info(self.conn, queue.get_token(self.conn, self.tokens[index]))

    def test_positions_and_waiting_time(self):
        self.assertEqual([self.info(i)["position"] for i in range(4)], [1, 2, 3, 4])
        self.assertEqual([self.info(i)["wait_minutes"] for i in range(4)], [0, 5, 10, 15])

    def test_waiting_time_uses_department_average(self):
        u = self.make_user("Other", "other@test.com")
        a = queue.book_token(self.conn, u, self.bil)           # avg 10, first in line
        v = self.make_user("Other2", "other2@test.com")
        b = queue.book_token(self.conn, v, self.bil)
        self.assertEqual(queue.queue_info(self.conn, queue.get_token(self.conn, b))["wait_minutes"], 10)

    def test_being_served_counts_in_waiting_time(self):
        queue.call_next(self.conn, self.gen)
        self.assertEqual(self.info(0)["position"], 0)
        self.assertEqual(self.info(1)["position"], 1)
        self.assertEqual(self.info(1)["wait_minutes"], 5)        # one person being served
        self.assertEqual(self.info(3)["wait_minutes"], 15)   # 2 waiting ahead + 1 being served

    def test_cancelled_and_skipped_tokens_leave_the_queue(self):
        queue.cancel_by_user(self.conn, self.tokens[1], self.users[1])      # token 2 cancelled
        queue.set_status(self.conn, self.tokens[0], "skipped")             # token 1 skipped
        self.assertEqual(self.info(2)["position"], 1)
        self.assertEqual(self.info(3)["position"], 2)
        self.assertIsNone(self.info(1)["position"])
        self.assertIsNone(self.info(0)["position"])

    def test_department_overview(self):
        queue.call_next(self.conn, self.gen)
        row = [d for d in queue.department_overview(self.conn) if d["id"] == self.gen][0]
        self.assertEqual(row["serving_label"], "GEN-001")
        self.assertEqual(row["waiting_count"], 3)
        self.assertEqual(row["new_token_wait"], 20)


class CancellationTests(BaseTestCase):
    def test_user_can_cancel_waiting_token(self):
        (u,) = self.make_users(1)
        t = queue.book_token(self.conn, u, self.gen)
        queue.cancel_by_user(self.conn, t, u)
        token = queue.get_token(self.conn, t)
        self.assertEqual(token["status"], "cancelled")
        self.assertIsNotNone(token["finished_at"])

    def test_cannot_cancel_someone_elses_token(self):
        u1, u2 = self.make_users(2)
        t = queue.book_token(self.conn, u1, self.gen)
        with self.assertRaises(queue.QueueError):
            queue.cancel_by_user(self.conn, t, u2)
        self.assertEqual(queue.get_token(self.conn, t)["status"], "waiting")

    def test_cannot_cancel_served_token(self):
        (u,) = self.make_users(1)
        t = queue.book_token(self.conn, u, self.gen)
        queue.call_next(self.conn, self.gen)
        with self.assertRaises(queue.QueueError):
            queue.cancel_by_user(self.conn, t, u)

    def test_cancel_route_and_other_user_blocked(self):
        u1, u2 = self.make_users(2)
        t = queue.book_token(self.conn, u1, self.gen)
        self.login("user2@test.com")
        r = self.client.post(f"/token/{t}/cancel", follow_redirects=True)
        self.assertIn(b"Token not found", r.data)
        self.assertEqual(queue.get_token(self.conn, t)["status"], "waiting")
        other = self.app.test_client()
        self.login("user1@test.com", client=other)
        r = other.post(f"/token/{t}/cancel", follow_redirects=True)
        self.assertIn(b"cancelled", r.data)
        self.assertEqual(queue.get_token(self.conn, t)["status"], "cancelled")

    def test_next_person_notified_when_ahead_cancels(self):
        u1, u2 = self.make_users(2)
        t1 = queue.book_token(self.conn, u1, self.gen)
        queue.book_token(self.conn, u2, self.gen)
        before = notes.unread_count(self.conn, u2)
        queue.cancel_by_user(self.conn, t1, u1)
        self.assertEqual(notes.unread_count(self.conn, u2), before + 1)
        self.assertIn("next in line", notes.list_for_user(self.conn, u2)[0]["message"])


class CallNextTests(BaseTestCase):
    def test_calls_lowest_waiting_token_and_notifies(self):
        u1, u2, u3 = self.make_users(3)
        t1, t2, t3 = [queue.book_token(self.conn, u, self.gen) for u in (u1, u2, u3)]
        token = queue.call_next(self.conn, self.gen)
        self.assertEqual(token["id"], t1)
        self.assertEqual(token["status"], "serving")
        self.assertIsNotNone(token["called_at"])
        self.assertIn("your turn", notes.list_for_user(self.conn, u1)[0]["message"])
        self.assertIn("next in line", notes.list_for_user(self.conn, u2)[0]["message"])

    def test_calling_next_completes_previous_and_skips_cancelled(self):
        u1, u2, u3 = self.make_users(3)
        t1, t2, t3 = [queue.book_token(self.conn, u, self.gen) for u in (u1, u2, u3)]
        queue.call_next(self.conn, self.gen)
        queue.cancel_by_user(self.conn, t2, u2)
        nxt = queue.call_next(self.conn, self.gen)
        self.assertEqual(nxt["id"], t3)                                   # cancelled token skipped over
        self.assertEqual(queue.get_token(self.conn, t1)["status"], "completed")
        servings = self.conn.execute("SELECT COUNT(*) FROM tokens WHERE status='serving'").fetchone()[0]
        self.assertEqual(servings, 1)

    def test_call_next_with_empty_queue(self):
        with self.assertRaises(queue.QueueError):
            queue.call_next(self.conn, self.gen)

    def test_departments_are_independent(self):
        u1, u2 = self.make_users(2)
        queue.book_token(self.conn, u1, self.gen)
        b = queue.book_token(self.conn, u2, self.bil)
        queue.call_next(self.conn, self.bil)
        self.assertEqual(queue.get_token(self.conn, b)["status"], "serving")
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM tokens WHERE status='serving' AND department_id=?",
                                           (self.gen,)).fetchone()[0], 0)

    def test_status_transitions_enforced(self):
        (u,) = self.make_users(1)
        t = queue.book_token(self.conn, u, self.gen)
        with self.assertRaises(queue.QueueError):
            queue.set_status(self.conn, t, "completed")           # waiting -> completed not allowed
        with self.assertRaises(queue.QueueError):
            queue.set_status(self.conn, t, "banana")
        queue.set_status(self.conn, t, "serving")
        queue.set_status(self.conn, t, "completed")
        with self.assertRaises(queue.QueueError):
            queue.set_status(self.conn, t, "serving")             # finished tokens are final

    def test_skip_and_admin_cancel_notify_user(self):
        u1, u2 = self.make_users(2)
        t1 = queue.book_token(self.conn, u1, self.gen)
        t2 = queue.book_token(self.conn, u2, self.gen)
        queue.set_status(self.conn, t1, "skipped")
        queue.set_status(self.conn, t2, "cancelled")
        self.assertIn("skipped", notes.list_for_user(self.conn, u1)[0]["message"])
        self.assertIn("cancelled by the administrator", notes.list_for_user(self.conn, u2)[0]["message"])

    def test_admin_routes_call_next_and_change_status(self):
        u1, u2 = self.make_users(2)
        t1 = queue.book_token(self.conn, u1, self.gen)
        t2 = queue.book_token(self.conn, u2, self.gen)
        self.login_admin()
        r = self.client.post(f"/admin/departments/{self.gen}/call-next", follow_redirects=True)
        self.assertIn(b"Now serving GEN-001", r.data)
        r = self.client.post(f"/admin/tokens/{t1}/status", data={"status": "completed"}, follow_redirects=True)
        self.assertIn(b"is now completed", r.data)
        r = self.client.post(f"/admin/tokens/{t2}/status", data={"status": "hacked"}, follow_redirects=True)
        self.assertIn(b"Invalid status", r.data)

    def test_statistics(self):
        u1, u2, u3 = self.make_users(3)
        t = [queue.book_token(self.conn, u, self.gen) for u in (u1, u2, u3)]
        queue.call_next(self.conn, self.gen)
        queue.call_next(self.conn, self.gen)          # first completed, second serving
        queue.cancel_by_user(self.conn, t[2], u3)
        summary = queue.admin_summary(self.conn)
        self.assertEqual((summary["tokens"], summary["completed"], summary["pending"]), (3, 1, 0))
        today = queue.daily_stats(self.conn, 7)[-1]
        self.assertEqual((today["total"], today["completed"], today["cancelled"]), (3, 1, 1))
        self.assertIsNotNone(today["avg_wait"])
        self.assertEqual(len(queue.daily_stats(self.conn, 7)), 7)
