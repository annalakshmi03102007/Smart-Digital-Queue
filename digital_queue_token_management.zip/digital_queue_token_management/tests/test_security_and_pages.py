from services import queue_service as queue
from tests.base import BaseTestCase


class AuthorizationTests(BaseTestCase):
    ADMIN_URLS = ["/admin/", "/admin/tokens", "/admin/departments", "/admin/departments/new",
                  "/admin/appointments", f"/admin/departments/1/edit"]

    def test_anonymous_redirected_to_admin_login(self):
        for url in self.ADMIN_URLS:
            with self.subTest(url=url):
                r = self.client.get(url)
                self.assertEqual(r.status_code, 302)
                self.assertIn("/admin/login", r.headers["Location"])

    def test_normal_user_gets_403_on_admin_pages(self):
        self.make_user("Stu", "stu@test.com")
        self.login("stu@test.com")
        for url in self.ADMIN_URLS:
            with self.subTest(url=url):
                self.assertEqual(self.client.get(url).status_code, 403)

    def test_normal_user_cannot_change_tokens_or_call_next(self):
        (u,) = self.make_users(1)
        t = queue.book_token(self.conn, u, self.gen)
        self.login("user1@test.com")
        self.assertEqual(self.client.post(f"/admin/tokens/{t}/status", data={"status": "serving"}).status_code, 403)
        self.assertEqual(self.client.post(f"/admin/departments/{self.gen}/call-next").status_code, 403)
        self.assertEqual(self.client.post("/admin/departments/new", data={"name": "X"}).status_code, 403)
        self.assertEqual(queue.get_token(self.conn, t)["status"], "waiting")

    def test_anonymous_cannot_post_admin_actions(self):
        (u,) = self.make_users(1)
        t = queue.book_token(self.conn, u, self.gen)
        r = self.client.post(f"/admin/tokens/{t}/status", data={"status": "serving"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(queue.get_token(self.conn, t)["status"], "waiting")

    def test_admin_allowed(self):
        self.login_admin()
        for url in self.ADMIN_URLS:
            with self.subTest(url=url):
                self.assertEqual(self.client.get(url).status_code, 200)

    def test_admin_is_redirected_away_from_user_pages(self):
        self.login_admin()
        r = self.client.get("/dashboard")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/admin/", r.headers["Location"])

    def test_anonymous_cannot_use_user_pages_or_api(self):
        for url in ("/dashboard", "/book-token", "/queue", "/appointments", "/history", "/notifications"):
            self.assertEqual(self.client.get(url).status_code, 302, url)
        self.assertEqual(self.client.get("/api/queue").status_code, 401)
        self.assertEqual(self.client.get("/api/notifications/unread-count").status_code, 401)

    def test_deleted_user_session_is_dropped(self):
        uid = self.make_user("Gone", "gone@test.com")
        self.login("gone@test.com")
        self.conn.execute("DELETE FROM users WHERE id = ?", (uid,))
        self.assertEqual(self.client.get("/dashboard").status_code, 302)


class CsrfTests(BaseTestCase):
    csrf_enabled = True

    def test_post_without_token_rejected(self):
        self.make_user("Stu", "stu@test.com")
        r = self.client.post("/login", data={"email": "stu@test.com", "password": "Passw0rd123"})
        self.assertEqual(r.status_code, 400)
        self.assertIn(b"CSRF", r.data)

    def test_wrong_token_rejected(self):
        self.client.get("/login")
        r = self.client.post("/login", data={"csrf_token": "wrong", "email": "a@b.com", "password": "x"})
        self.assertEqual(r.status_code, 400)

    def test_valid_token_accepted(self):
        self.make_user("Stu", "stu@test.com")
        self.client.get("/login")
        with self.client.session_transaction() as sess:
            token = sess["_csrf"]
        r = self.client.post("/login", data={"csrf_token": token, "email": "stu@test.com",
                                             "password": "Passw0rd123"}, follow_redirects=True)
        self.assertIn(b"Welcome, Stu", r.data)

    def test_forms_contain_token(self):
        page = self.client.get("/login").data
        self.assertIn(b'name="csrf_token"', page)

    def test_logout_requires_token(self):
        self.make_user("Stu", "stu@test.com")
        self.client.get("/login")
        with self.client.session_transaction() as sess:
            token = sess["_csrf"]
        self.client.post("/login", data={"csrf_token": token, "email": "stu@test.com", "password": "Passw0rd123"})
        self.assertEqual(self.client.post("/logout").status_code, 400)


class InvalidInputTests(BaseTestCase):
    def test_booking_with_bad_department_values(self):
        self.make_user("Stu", "stu@test.com")
        self.login("stu@test.com")
        for value in ("abc", "", "-5", "0", "99999", "1; DROP TABLE users"):
            with self.subTest(value=value):
                r = self.client.post("/book-token", data={"department_id": value})
                self.assertEqual(r.status_code, 200)
                self.assertTrue(b"choose a department" in r.data or b"not available" in r.data)
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM tokens").fetchone()[0], 0)
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM users").fetchone()[0], 2)  # table intact

    def test_booking_via_form_works_and_blocks_duplicate(self):
        self.make_user("Stu", "stu@test.com")
        self.login("stu@test.com")
        r = self.client.post("/book-token", data={"department_id": str(self.gen)}, follow_redirects=True)
        self.assertIn(b"GEN-001", r.data)
        r = self.client.post("/book-token", data={"department_id": str(self.bil)})
        self.assertIn(b"already have an active token", r.data)

    def test_department_form_validation(self):
        self.login_admin()
        base = {"name": "Library", "code": "LIB", "description": "Books", "avg_service_minutes": "7"}
        cases = [({"name": ""}, b"Department name"), ({"code": "toolong"}, b"Code must be"),
                 ({"code": "1A"}, b"Code must be"), ({"avg_service_minutes": "0"}, b"Average service time"),
                 ({"avg_service_minutes": "abc"}, b"Average service time"),
                 ({"avg_service_minutes": "999"}, b"Average service time"),
                 ({"description": "x" * 201}, b"at most 200"),
                 ({"name": "General"}, b"already uses"), ({"code": "gen"}, b"already uses")]
        for overrides, expected in cases:
            with self.subTest(overrides=overrides):
                data = dict(base, **overrides)
                self.assertIn(expected, self.client.post("/admin/departments/new", data=data).data)
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM departments").fetchone()[0], 2)

    def test_admin_filters_with_garbage_do_not_crash(self):
        self.login_admin()
        for qs in ("?date=bad", "?department_id=abc", "?status=hax", "?q=%27%20OR%201%3D1%20--", "?date="):
            with self.subTest(qs=qs):
                self.assertEqual(self.client.get("/admin/tokens" + qs).status_code, 200)
                self.assertEqual(self.client.get("/admin/appointments" + qs).status_code, 200)

    def test_unknown_page_gives_404_page(self):
        r = self.client.get("/does-not-exist")
        self.assertEqual(r.status_code, 404)
        self.assertIn(b"Page not found", r.data)


class DepartmentManagementTests(BaseTestCase):
    def test_create_edit_toggle(self):
        self.login_admin()
        r = self.client.post("/admin/departments/new", data={
            "name": "Library", "code": "lib", "description": "Books", "avg_service_minutes": "7", "is_active": "1"},
            follow_redirects=True)
        self.assertIn(b"Department created", r.data)
        row = self.conn.execute("SELECT * FROM departments WHERE name='Library'").fetchone()
        self.assertEqual((row["code"], row["avg_service_minutes"], row["is_active"]), ("LIB", 7, 1))
        r = self.client.post(f"/admin/departments/{row['id']}/edit", data={
            "name": "Library Desk", "code": "LIB", "description": "", "avg_service_minutes": "9"},
            follow_redirects=True)
        self.assertIn(b"Department updated", r.data)
        row = self.conn.execute("SELECT * FROM departments WHERE id=?", (row["id"],)).fetchone()
        self.assertEqual((row["name"], row["avg_service_minutes"], row["is_active"]), ("Library Desk", 9, 0))
        self.client.post(f"/admin/departments/{row['id']}/toggle")
        self.assertEqual(self.conn.execute("SELECT is_active FROM departments WHERE id=?", (row["id"],)).fetchone()[0], 1)

    def test_inactive_department_not_bookable_from_ui(self):
        self.conn.execute("UPDATE departments SET is_active = 0 WHERE id = ?", (self.bil,))
        self.make_user("Stu", "stu@test.com")
        self.login("stu@test.com")
        page = self.client.get("/book-token").data
        self.assertIn(b"General", page)
        self.assertNotIn(b"Billing", page)


class PageAndApiTests(BaseTestCase):
    def test_all_user_pages_render_and_live_api(self):
        (u,) = self.make_users(1)
        queue.book_token(self.conn, u, self.gen)
        self.login("user1@test.com")
        for url in ("/", "/dashboard", "/book-token", "/queue", "/appointments", "/history",
                    "/notifications", "/account/password"):
            with self.subTest(url=url):
                self.assertEqual(self.client.get(url).status_code, 200)
        data = self.client.get("/api/queue").get_json()
        self.assertEqual(data["my_token"]["label"], "GEN-001")
        self.assertEqual(data["my_token"]["position"], 1)
        self.assertEqual(len(data["departments"]), 2)
        self.assertEqual(self.client.get("/api/notifications/unread-count").get_json()["count"], 1)

    def test_live_status_changes_after_admin_calls_next(self):
        u1, u2 = self.make_users(2)
        queue.book_token(self.conn, u1, self.gen)
        queue.book_token(self.conn, u2, self.gen)
        self.login("user2@test.com")
        self.assertEqual(self.client.get("/api/queue").get_json()["my_token"]["position"], 2)
        queue.call_next(self.conn, self.gen)
        mine = self.client.get("/api/queue").get_json()["my_token"]
        self.assertEqual(mine["position"], 1)
        self.assertEqual(mine["wait_minutes"], 5)
        queue.call_next(self.conn, self.gen)
        self.assertEqual(self.client.get("/api/queue").get_json()["my_token"]["status"], "serving")

    def test_notifications_page_and_mark_read(self):
        (u,) = self.make_users(1)
        queue.book_token(self.conn, u, self.gen)
        self.login("user1@test.com")
        self.assertIn(b"booked for General", self.client.get("/notifications").data)
        self.client.post("/notifications/read", follow_redirects=True)
        self.assertEqual(self.client.get("/api/notifications/unread-count").get_json()["count"], 0)

    def test_history_shows_only_own_tokens(self):
        u1, u2 = self.make_users(2)
        queue.book_token(self.conn, u1, self.gen)
        queue.book_token(self.conn, u2, self.bil)
        self.login("user1@test.com")
        page = self.client.get("/history").data
        self.assertIn(b"GEN-001", page)
        self.assertNotIn(b"BIL-001", page)

    def test_all_admin_pages_render_with_data(self):
        u1, u2 = self.make_users(2)
        queue.book_token(self.conn, u1, self.gen)
        queue.book_token(self.conn, u2, self.bil)
        queue.call_next(self.conn, self.gen)
        self.login_admin()
        page = self.client.get("/admin/").data
        self.assertIn(b"Total users", page)
        self.assertIn(b"dailyChart", page)
        tokens = self.client.get(f"/admin/tokens?status=serving&department_id={self.gen}").data
        self.assertIn(b"GEN-001", tokens)
        self.assertNotIn(b"BIL-001", tokens)
        found = self.client.get("/admin/tokens?q=user2").data
        self.assertIn(b"user2@test.com", found)
        self.assertNotIn(b"user1@test.com", found)
        self.assertIn(b"GEN-001", self.client.get("/admin/tokens?date=").data)
