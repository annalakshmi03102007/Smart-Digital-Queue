from tests.base import PASSWORD, BaseTestCase


class RegistrationTests(BaseTestCase):
    def register(self, **overrides):
        data = {"name": "Test Student", "email": "student@test.com",
                "password": PASSWORD, "confirm_password": PASSWORD}
        data.update(overrides)
        return self.client.post("/register", data=data, follow_redirects=True)

    def test_registration_success_and_password_is_hashed(self):
        response = self.register()
        self.assertIn(b"Account created", response.data)
        row = self.conn.execute("SELECT * FROM users WHERE email = 'student@test.com'").fetchone()
        self.assertIsNotNone(row)
        self.assertEqual(row["role"], "user")
        self.assertNotEqual(row["password_hash"], PASSWORD)
        self.assertNotIn(PASSWORD, row["password_hash"])

    def test_duplicate_email_rejected_case_insensitive(self):
        self.register()
        response = self.register(email="STUDENT@test.com")
        self.assertIn(b"already exists", response.data)
        count = self.conn.execute("SELECT COUNT(*) FROM users WHERE email LIKE 'student@test.com'").fetchone()[0]
        self.assertEqual(count, 1)

    def test_invalid_inputs_rejected(self):
        cases = [
            ({"name": "A"}, b"Name must be"),
            ({"email": "not-an-email"}, b"valid email"),
            ({"password": "short1", "confirm_password": "short1"}, b"at least 8"),
            ({"password": "onlyletters", "confirm_password": "onlyletters"}, b"letter and one number"),
            ({"confirm_password": "Different123"}, b"do not match"),
        ]
        for overrides, expected in cases:
            with self.subTest(overrides=overrides):
                response = self.register(**overrides)
                self.assertIn(expected, response.data)
        self.assertIsNone(self.conn.execute("SELECT 1 FROM users WHERE email='student@test.com'").fetchone())

    def test_xss_in_name_is_escaped(self):
        self.register(name="<script>alert(1)</script>")
        self.login("student@test.com")
        page = self.client.get("/dashboard").data
        self.assertNotIn(b"<script>alert(1)</script>", page)


class LoginTests(BaseTestCase):
    def test_user_login_logout(self):
        self.make_user("Stu", "stu@test.com")
        response = self.login("stu@test.com")
        self.assertIn(b"Welcome, Stu", response.data)
        self.assertEqual(self.client.get("/dashboard").status_code, 200)
        self.client.post("/logout", follow_redirects=True)
        self.assertEqual(self.client.get("/dashboard").status_code, 302)

    def test_wrong_password_and_unknown_email_give_same_message(self):
        self.make_user("Stu", "stu@test.com")
        a = self.login("stu@test.com", "WrongPass1")
        b = self.login("nobody@test.com", "WrongPass1")
        self.assertIn(b"Invalid email or password", a.data)
        self.assertIn(b"Invalid email or password", b.data)

    def test_admin_cannot_use_user_login_and_user_cannot_use_admin_login(self):
        self.make_user("Stu", "stu@test.com")
        self.assertIn(b"Invalid email or password", self.login("admin@test.com").data)
        self.assertIn(b"Invalid email or password", self.login("stu@test.com", admin=True).data)

    def test_login_redirect_goes_to_correct_dashboard(self):
        self.make_user("Stu", "stu@test.com")
        r = self.client.post("/login", data={"email": "stu@test.com", "password": PASSWORD})
        self.assertTrue(r.headers["Location"].endswith("/dashboard"))
        other = self.app.test_client()
        r = other.post("/admin/login", data={"email": "admin@test.com", "password": PASSWORD})
        self.assertTrue(r.headers["Location"].endswith("/admin/"))

    def test_open_redirect_is_blocked(self):
        self.make_user("Stu", "stu@test.com")
        for evil in ("//evil.com", "https://evil.com", "/\\evil.com"):
            client = self.app.test_client()
            r = client.post("/login?next=" + evil, data={"email": "stu@test.com", "password": PASSWORD})
            self.assertTrue(r.headers["Location"].endswith("/dashboard"), evil)

    def test_safe_next_is_followed(self):
        self.make_user("Stu", "stu@test.com")
        r = self.client.post("/login?next=/history", data={"email": "stu@test.com", "password": PASSWORD})
        self.assertTrue(r.headers["Location"].endswith("/history"))

    def test_change_password(self):
        self.make_user("Stu", "stu@test.com")
        self.login("stu@test.com")
        r = self.client.post("/account/password", data={
            "current_password": "Wrong123x", "new_password": "NewPass456", "confirm_password": "NewPass456"})
        self.assertIn(b"not correct", r.data)
        r = self.client.post("/account/password", data={
            "current_password": PASSWORD, "new_password": "NewPass456", "confirm_password": "NewPass456"},
            follow_redirects=True)
        self.assertIn(b"Password changed", r.data)
        other = self.app.test_client()
        self.assertIn(b"Welcome", self.login("stu@test.com", "NewPass456", client=other).data)

    def test_default_admin_password_enforced_when_enabled(self):
        self.make_user("Boss", "boss@test.com", role="admin", must_change=1)
        self.app.config["ENFORCE_PASSWORD_CHANGE"] = True
        self.login("boss@test.com", admin=True)
        r = self.client.get("/admin/")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/account/password", r.headers["Location"])
        self.client.post("/account/password", data={
            "current_password": PASSWORD, "new_password": "BrandNew789", "confirm_password": "BrandNew789"})
        self.assertEqual(self.client.get("/admin/").status_code, 200)
