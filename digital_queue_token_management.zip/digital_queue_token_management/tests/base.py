"""Shared test helpers. Every test gets a brand-new temporary database."""
import os
import shutil
import tempfile
import unittest
from datetime import date, timedelta

from werkzeug.security import generate_password_hash

import database
from app import create_app

PASSWORD = "Passw0rd123"


class BaseTestCase(unittest.TestCase):
    csrf_enabled = False

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp, "test.db")
        self.app = create_app({
            "TESTING": True,
            "DATABASE": self.db_path,
            "SECRET_KEY": "test-secret",
            "CSRF_ENABLED": self.csrf_enabled,
        })
        self.conn = database.connect(self.db_path)       # direct connection for services
        database.init_schema(self.conn)
        self.client = self.app.test_client()

        self.admin_id = self.make_user("Admin", "admin@test.com", role="admin")
        self.gen = self.make_department("General", "GEN", 5)
        self.bil = self.make_department("Billing", "BIL", 10)

    def tearDown(self):
        self.conn.close()
        shutil.rmtree(self.tmp, ignore_errors=True)

    # ---- data helpers ----
    def make_user(self, name, email, role="user", password=PASSWORD, must_change=0):
        cur = self.conn.execute(
            "INSERT INTO users (name, email, password_hash, role, must_change_password) "
            "VALUES (?, ?, ?, ?, ?)",
            (name, email, generate_password_hash(password, method="pbkdf2:sha256:1000"), role, must_change))
        return cur.lastrowid

    def make_department(self, name, code, minutes=5, active=1):
        return self.conn.execute(
            "INSERT INTO departments (name, code, avg_service_minutes, is_active) VALUES (?, ?, ?, ?)",
            (name, code, minutes, active)).lastrowid

    def make_users(self, count):
        return [self.make_user(f"User {i}", f"user{i}@test.com") for i in range(1, count + 1)]

    # ---- http helpers ----
    def login(self, email, password=PASSWORD, admin=False, client=None):
        client = client or self.client
        return client.post("/admin/login" if admin else "/login",
                           data={"email": email, "password": password}, follow_redirects=True)

    def login_admin(self):
        return self.login("admin@test.com", admin=True)

    @staticmethod
    def tomorrow():
        return (date.today() + timedelta(days=1)).isoformat()

    @staticmethod
    def yesterday():
        return (date.today() - timedelta(days=1)).isoformat()
