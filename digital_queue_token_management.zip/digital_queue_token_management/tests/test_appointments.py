from services import appointment_service as appts
from services import notification_service as notes
from tests.base import BaseTestCase


class AppointmentServiceTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.u1, self.u2 = self.make_users(2)
        self.settings = self.app.config

    def book(self, user=None, dept=None, day=None, time="10:00", note=""):
        day = self.tomorrow() if day is None else day      # "" must stay "" (invalid input)
        return appts.book_appointment(self.conn, self.settings, user or self.u1, dept or self.gen,
                                      day, time, note)

    def test_book_success(self):
        aid = self.book(note="Bring ID")
        row = self.conn.execute("SELECT * FROM appointments WHERE id = ?", (aid,)).fetchone()
        self.assertEqual((row["status"], row["appointment_time"], row["notes"]), ("booked", "10:00", "Bring ID"))
        self.assertEqual(notes.unread_count(self.conn, self.u1), 1)

    def test_double_booking_same_slot_rejected(self):
        self.book()
        with self.assertRaises(appts.AppointmentError):
            self.book(user=self.u2)
        # different department or time is fine
        self.book(user=self.u2, dept=self.bil)
        self.book(user=self.u2, time="10:30")

    def test_cancelled_slot_can_be_rebooked(self):
        aid = self.book()
        appts.cancel_by_user(self.conn, aid, self.u1)
        self.book(user=self.u2)

    def test_invalid_dates_and_times_rejected(self):
        bad = [(self.yesterday(), "10:00"), ("2000-01-01", "10:00"), ("not-a-date", "10:00"),
               ("", "10:00"), (self.tomorrow(), "10:07"), (self.tomorrow(), ""), ("2999-01-01", "10:00")]
        for day, time in bad:
            with self.subTest(day=day, time=time):
                with self.assertRaises(appts.AppointmentError):
                    self.book(day=day, time=time)
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM appointments").fetchone()[0], 0)

    def test_invalid_department_rejected(self):
        off = self.make_department("Closed", "CLS", 5, active=0)
        for dept in (off, 9999):
            with self.assertRaises(appts.AppointmentError):
                self.book(dept=dept)

    def test_cannot_cancel_other_users_appointment(self):
        aid = self.book()
        with self.assertRaises(appts.AppointmentError):
            appts.cancel_by_user(self.conn, aid, self.u2)

    def test_admin_status_changes(self):
        aid = self.book()
        appts.set_status(self.conn, aid, "confirmed")
        appts.set_status(self.conn, aid, "completed")
        with self.assertRaises(appts.AppointmentError):
            appts.set_status(self.conn, aid, "cancelled")
        self.assertIn("completed", notes.list_for_user(self.conn, self.u1)[0]["message"])

    def test_slot_availability(self):
        self.book(time="09:30")
        slots = {s["time"]: s["available"] for s in appts.slot_status(self.conn, self.settings, self.gen, self.tomorrow())}
        self.assertFalse(slots["09:30"])
        self.assertTrue(slots["09:00"])
        self.assertEqual(slots.get("17:00"), None)           # end time is excluded


class AppointmentRouteTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.u1, = self.make_users(1)
        self.login("user1@test.com")

    def post(self, **overrides):
        data = {"department_id": str(self.gen), "appointment_date": self.tomorrow(),
                "appointment_time": "11:00", "notes": "hello"}
        data.update(overrides)
        return self.client.post("/appointments", data=data, follow_redirects=True)

    def test_book_via_form_and_cancel(self):
        self.assertIn(b"Appointment booked", self.post().data)
        aid = self.conn.execute("SELECT id FROM appointments").fetchone()[0]
        self.assertIn(b"Appointment cancelled",
                      self.client.post(f"/appointments/{aid}/cancel", follow_redirects=True).data)

    def test_invalid_form_values(self):
        self.assertIn(b"choose a department", self.post(department_id="abc").data)
        self.assertIn(b"valid date", self.post(appointment_date="31-12-2030").data)
        self.assertIn(b"past", self.post(appointment_date=self.yesterday()).data)
        self.assertIn(b"valid time slot", self.post(appointment_time="25:00").data)
        self.assertIn(b"at most 200", self.post(notes="x" * 201).data)
        self.assertIn(b"not available", self.post(department_id="9999").data)
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM appointments").fetchone()[0], 0)

    def test_slot_api(self):
        r = self.client.get(f"/api/appointment-slots?department_id={self.gen}&date={self.tomorrow()}")
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.get_json()["slots"])
        self.assertEqual(self.client.get("/api/appointment-slots?department_id=x&date=2030-01-01").status_code, 400)
        self.assertEqual(self.client.get(f"/api/appointment-slots?department_id={self.gen}&date=bad").status_code, 400)

    def test_admin_can_manage_appointments(self):
        self.post()
        aid = self.conn.execute("SELECT id FROM appointments").fetchone()[0]
        admin = self.app.test_client()
        self.login("admin@test.com", admin=True, client=admin)
        page = admin.get(f"/admin/appointments?date={self.tomorrow()}&status=booked")
        self.assertIn(b"user1@test.com", page.data)
        r = admin.post(f"/admin/appointments/{aid}/status", data={"status": "confirmed"}, follow_redirects=True)
        self.assertIn(b"Appointment updated", r.data)
        self.assertEqual(self.conn.execute("SELECT status FROM appointments").fetchone()[0], "confirmed")
        bad = admin.post(f"/admin/appointments/{aid}/status", data={"status": "nope"}, follow_redirects=True)
        self.assertIn(b"Invalid status", bad.data)
