"""All queue / token business rules live here (no Flask code)."""
from datetime import date, datetime, timedelta

from database import transaction
from services import notification_service as notes


class QueueError(Exception):
    """A friendly, user-readable problem (shown in a flash message)."""


ALL_STATUSES = ("waiting", "serving", "completed", "skipped", "cancelled")
ACTIVE_STATUSES = ("waiting", "serving")

# Which status changes are allowed.
TRANSITIONS = {
    "waiting": {"serving", "skipped", "cancelled"},
    "serving": {"completed", "skipped", "cancelled"},
}

TOKEN_SELECT = """
    SELECT t.*, d.name AS dept_name, d.code AS dept_code,
           d.avg_service_minutes AS avg_minutes,
           u.name AS user_name, u.email AS user_email
      FROM tokens t
      JOIN departments d ON d.id = t.department_id
      JOIN users u       ON u.id = t.user_id
"""


def today():
    return date.today().isoformat()


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def token_label(code, number):
    return f"{code}-{number:03d}"


def label_of(row):
    return token_label(row["dept_code"], row["token_number"])


def get_token(db, token_id):
    return db.execute(TOKEN_SELECT + " WHERE t.id = ?", (token_id,)).fetchone()


def user_active_token(db, user_id, service_date=None):
    """The user's first active (waiting/serving) token for the day, or None."""
    return db.execute(
        TOKEN_SELECT
        + " WHERE t.user_id = ? AND t.service_date = ? AND t.status IN ('waiting','serving')"
        + " ORDER BY t.id LIMIT 1",
        (user_id, service_date or today()),
    ).fetchone()


# --------------------------------------------------------------------------
# Position and waiting time
# --------------------------------------------------------------------------
def queue_info(db, token):
    """Queue position and estimated wait for one token.

    position = number of WAITING tokens ahead of it + 1.
    Cancelled, skipped and completed tokens are not counted.
    wait = (people ahead + the person being served now) * average service minutes.
    """
    if token["status"] == "waiting":
        ahead = db.execute(
            "SELECT COUNT(*) FROM tokens WHERE department_id = ? AND service_date = ? "
            "AND status = 'waiting' AND token_number < ?",
            (token["department_id"], token["service_date"], token["token_number"]),
        ).fetchone()[0]
        serving = db.execute(
            "SELECT COUNT(*) FROM tokens WHERE department_id = ? AND service_date = ? "
            "AND status = 'serving'",
            (token["department_id"], token["service_date"]),
        ).fetchone()[0]
        return {"position": ahead + 1, "ahead": ahead,
                "wait_minutes": (ahead + serving) * token["avg_minutes"]}
    if token["status"] == "serving":
        return {"position": 0, "ahead": 0, "wait_minutes": 0}
    return {"position": None, "ahead": None, "wait_minutes": None}


def department_overview(db, service_date=None, include_inactive=False):
    """One row per department with waiting count and who is being served."""
    day = service_date or today()
    sql = """
        SELECT d.*,
          (SELECT COUNT(*) FROM tokens t WHERE t.department_id = d.id
              AND t.service_date = :day AND t.status = 'waiting')          AS waiting_count,
          (SELECT t.token_number FROM tokens t WHERE t.department_id = d.id
              AND t.service_date = :day AND t.status = 'serving'
              ORDER BY t.token_number LIMIT 1)                             AS serving_number,
          (SELECT COALESCE(MAX(t.token_number), 0) FROM tokens t
              WHERE t.department_id = d.id AND t.service_date = :day)      AS last_number
          FROM departments d
    """
    if not include_inactive:
        sql += " WHERE d.is_active = 1"
    sql += " ORDER BY d.name"
    rows = db.execute(sql, {"day": day}).fetchall()
    result = []
    for r in rows:
        item = dict(r)
        item["serving_label"] = (token_label(r["code"], r["serving_number"])
                                 if r["serving_number"] else None)
        busy = 1 if r["serving_number"] else 0
        item["new_token_wait"] = (r["waiting_count"] + busy) * r["avg_service_minutes"]
        result.append(item)
    return result


# --------------------------------------------------------------------------
# Booking and status changes (each one is a single database transaction)
# --------------------------------------------------------------------------
def book_token(db, user_id, department_id, service_date=None, allow_multiple=False):
    """Create a token with the next sequential number. Returns the new token id."""
    day = service_date or today()
    with transaction(db):
        dept = db.execute("SELECT * FROM departments WHERE id = ?", (department_id,)).fetchone()
        if dept is None or not dept["is_active"]:
            raise QueueError("That department is not available.")

        if not allow_multiple:
            existing = db.execute(
                "SELECT t.token_number, d.code FROM tokens t "
                "JOIN departments d ON d.id = t.department_id "
                "WHERE t.user_id = ? AND t.service_date = ? AND t.status IN ('waiting','serving')",
                (user_id, day),
            ).fetchone()
            if existing:
                raise QueueError(
                    f"You already have an active token "
                    f"({token_label(existing['code'], existing['token_number'])}) for today. "
                    "Cancel it or wait until it is finished before booking another."
                )

        # MAX includes cancelled/skipped tokens, so numbers are never reused.
        number = db.execute(
            "SELECT COALESCE(MAX(token_number), 0) + 1 FROM tokens "
            "WHERE department_id = ? AND service_date = ?",
            (department_id, day),
        ).fetchone()[0]
        cur = db.execute(
            "INSERT INTO tokens (user_id, department_id, service_date, token_number, status, created_at) "
            "VALUES (?, ?, ?, ?, 'waiting', ?)",
            (user_id, department_id, day, number, now_str()),
        )
        token_id = cur.lastrowid
        token = get_token(db, token_id)
        info = queue_info(db, token)
        notes.create(
            db, user_id,
            f"Token {label_of(token)} booked for {dept['name']}. "
            f"Your position is {info['position']} and the estimated wait is "
            f"{info['wait_minutes']} minute(s).",
        )
    return token_id


def _finish(db, token_id, status):
    db.execute(
        "UPDATE tokens SET status = ?, finished_at = ? WHERE id = ?",
        (status, now_str(), token_id),
    )


def _apply_status(db, token, new_status, actor):
    """Change a token's status. MUST be called inside a transaction."""
    if new_status not in ALL_STATUSES:
        raise QueueError("Invalid status.")
    if new_status not in TRANSITIONS.get(token["status"], set()):
        raise QueueError(f"A {token['status']} token cannot be changed to {new_status}.")

    label = label_of(token)
    uid = token["user_id"]

    if new_status == "serving":
        # Only one person is served at a time in a department: finish the previous one.
        for cur in db.execute(
            TOKEN_SELECT + " WHERE t.department_id = ? AND t.service_date = ? "
            "AND t.status = 'serving' AND t.id != ?",
            (token["department_id"], token["service_date"], token["id"]),
        ).fetchall():
            _finish(db, cur["id"], "completed")
            notes.create(db, cur["user_id"], f"Token {label_of(cur)} is completed. Thank you!")
        db.execute("UPDATE tokens SET status = 'serving', called_at = ? WHERE id = ?",
                   (now_str(), token["id"]))
        notes.create(db, uid, f"It is your turn! Token {label} is now being served at "
                              f"{token['dept_name']}. Please go to the counter.")
    elif new_status == "completed":
        _finish(db, token["id"], "completed")
        notes.create(db, uid, f"Token {label} is completed. Thank you!")
    elif new_status == "skipped":
        _finish(db, token["id"], "skipped")
        notes.create(db, uid, f"Token {label} was skipped because you were not at the counter "
                              "when it was called. Please book a new token.")
    elif new_status == "cancelled":
        _finish(db, token["id"], "cancelled")
        if actor == "admin":
            notes.create(db, uid, f"Token {label} was cancelled by the administrator.")
        else:
            notes.create(db, uid, f"You cancelled token {label}.")

    _notify_next_in_line(db, token["department_id"], token["service_date"])


def _notify_next_in_line(db, department_id, service_date):
    """Tell the person who is now first in the waiting line (only once)."""
    nxt = db.execute(
        TOKEN_SELECT + " WHERE t.department_id = ? AND t.service_date = ? AND t.status = 'waiting' "
        "ORDER BY t.token_number LIMIT 1",
        (department_id, service_date),
    ).fetchone()
    if nxt is not None and not nxt["next_notified"]:
        db.execute("UPDATE tokens SET next_notified = 1 WHERE id = ?", (nxt["id"],))
        notes.create(db, nxt["user_id"],
                     f"You are next in line for token {label_of(nxt)}. Please be ready near the counter.")


def set_status(db, token_id, new_status):
    """Admin action: serving / completed / skipped / cancelled."""
    with transaction(db):
        token = get_token(db, token_id)
        if token is None:
            raise QueueError("Token not found.")
        _apply_status(db, token, new_status, actor="admin")
    return get_token(db, token_id)


def call_next(db, department_id, service_date=None):
    """Call the lowest-numbered waiting token. Finishes the one being served."""
    day = service_date or today()
    with transaction(db):
        nxt = db.execute(
            TOKEN_SELECT + " WHERE t.department_id = ? AND t.service_date = ? AND t.status = 'waiting' "
            "ORDER BY t.token_number LIMIT 1",
            (department_id, day),
        ).fetchone()
        if nxt is None:
            raise QueueError("No tokens are waiting in this queue. If the current "
                             "customer is finished, mark their token as completed.")
        _apply_status(db, nxt, "serving", actor="admin")
    return get_token(db, nxt["id"])


def cancel_by_user(db, token_id, user_id):
    """A user may cancel only their OWN token and only while it is still waiting."""
    with transaction(db):
        token = get_token(db, token_id)
        if token is None or token["user_id"] != user_id:
            raise QueueError("Token not found.")
        if token["status"] != "waiting":
            raise QueueError("Only tokens that are still waiting can be cancelled.")
        _apply_status(db, token, "cancelled", actor="user")


# --------------------------------------------------------------------------
# Listing and statistics
# --------------------------------------------------------------------------
def list_tokens(db, service_date=None, department_id=None, status=None, q=None,
                user_id=None, limit=500):
    where, params = [], []
    if service_date:
        where.append("t.service_date = ?"); params.append(service_date)
    if department_id:
        where.append("t.department_id = ?"); params.append(department_id)
    if status:
        where.append("t.status = ?"); params.append(status)
    if user_id:
        where.append("t.user_id = ?"); params.append(user_id)
    if q:
        like = f"%{q}%"
        where.append("(u.name LIKE ? OR u.email LIKE ? OR d.code LIKE ? "
                     "OR CAST(t.token_number AS TEXT) = ?)")
        params += [like, like, like, q]
    sql = TOKEN_SELECT
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY t.service_date DESC, t.department_id, t.token_number LIMIT ?"
    params.append(limit)
    return db.execute(sql, params).fetchall()


def admin_summary(db):
    one = lambda sql, *p: db.execute(sql, p).fetchone()[0]
    return {
        "users": one("SELECT COUNT(*) FROM users WHERE role = 'user'"),
        "tokens": one("SELECT COUNT(*) FROM tokens"),
        "pending": one("SELECT COUNT(*) FROM tokens WHERE status = 'waiting'"),
        "completed": one("SELECT COUNT(*) FROM tokens WHERE status = 'completed'"),
        "tokens_today": one("SELECT COUNT(*) FROM tokens WHERE service_date = ?", today()),
        "appointments_active": one(
            "SELECT COUNT(*) FROM appointments WHERE status IN ('booked','confirmed')"),
    }


def daily_stats(db, days=7):
    """Counts per day for the last `days` days (days with no tokens show zeros)."""
    start = date.today() - timedelta(days=days - 1)
    rows = db.execute(
        """SELECT service_date,
                  COUNT(*) AS total,
                  SUM(status = 'completed') AS completed,
                  SUM(status = 'skipped')   AS skipped,
                  SUM(status = 'cancelled') AS cancelled,
                  SUM(status = 'waiting')   AS waiting,
                  AVG(CASE WHEN called_at IS NOT NULL
                      THEN (julianday(called_at) - julianday(created_at)) * 1440 END) AS avg_wait
             FROM tokens WHERE service_date >= ? GROUP BY service_date""",
        (start.isoformat(),),
    ).fetchall()
    by_day = {r["service_date"]: r for r in rows}
    result = []
    for i in range(days):
        d = (start + timedelta(days=i)).isoformat()
        r = by_day.get(d)
        result.append({
            "date": d,
            "total": r["total"] if r else 0,
            "completed": r["completed"] if r else 0,
            "skipped": r["skipped"] if r else 0,
            "cancelled": r["cancelled"] if r else 0,
            "waiting": r["waiting"] if r else 0,
            "avg_wait": round(r["avg_wait"], 1) if r and r["avg_wait"] is not None else None,
        })
    return result


def department_stats(db, service_date=None):
    day = service_date or today()
    return db.execute(
        """SELECT d.name, d.code,
                  COUNT(t.id) AS total,
                  COALESCE(SUM(t.status = 'waiting'), 0)   AS waiting,
                  COALESCE(SUM(t.status = 'serving'), 0)   AS serving,
                  COALESCE(SUM(t.status = 'completed'), 0) AS completed,
                  COALESCE(SUM(t.status = 'skipped'), 0)   AS skipped,
                  COALESCE(SUM(t.status = 'cancelled'), 0) AS cancelled
             FROM departments d
             LEFT JOIN tokens t ON t.department_id = d.id AND t.service_date = ?
            GROUP BY d.id ORDER BY d.name""",
        (day,),
    ).fetchall()
