"""Appointment booking rules (no Flask code)."""
import sqlite3
from datetime import date, datetime, timedelta

from database import transaction
from services import notification_service as notes


class AppointmentError(Exception):
    """A friendly, user-readable problem."""


ACTIVE_STATUSES = ("booked", "confirmed")
ALL_STATUSES = ("booked", "confirmed", "completed", "cancelled")
TRANSITIONS = {
    "booked": {"confirmed", "completed", "cancelled"},
    "confirmed": {"completed", "cancelled"},
}

APPT_SELECT = """
    SELECT a.*, d.name AS dept_name, d.code AS dept_code,
           u.name AS user_name, u.email AS user_email
      FROM appointments a
      JOIN departments d ON d.id = a.department_id
      JOIN users u       ON u.id = a.user_id
"""


def slot_times(settings):
    """List of 'HH:MM' strings, e.g. ['09:00', '09:30', ...]."""
    start = datetime.strptime(settings["APPOINTMENT_START"], "%H:%M")
    end = datetime.strptime(settings["APPOINTMENT_END"], "%H:%M")
    step = timedelta(minutes=settings["APPOINTMENT_INTERVAL_MINUTES"])
    slots, current = [], start
    while current < end:
        slots.append(current.strftime("%H:%M"))
        current += step
    return slots


def parse_date(value):
    try:
        return datetime.strptime(value or "", "%Y-%m-%d").date()
    except ValueError:
        raise AppointmentError("Please choose a valid date.")


def check_date_allowed(day, settings):
    if day < date.today():
        raise AppointmentError("You cannot book an appointment in the past.")
    if day > date.today() + timedelta(days=settings["APPOINTMENT_MAX_DAYS_AHEAD"]):
        raise AppointmentError(
            f"Appointments can only be booked up to {settings['APPOINTMENT_MAX_DAYS_AHEAD']} days ahead.")


def slot_status(db, settings, department_id, day_str):
    """Every slot for a date, marked available or not."""
    day = parse_date(day_str)
    check_date_allowed(day, settings)
    taken = {
        r[0] for r in db.execute(
            "SELECT appointment_time FROM appointments WHERE department_id = ? "
            "AND appointment_date = ? AND status IN ('booked','confirmed')",
            (department_id, day_str),
        ).fetchall()
    }
    now = datetime.now()
    result = []
    for t in slot_times(settings):
        slot_dt = datetime.strptime(f"{day_str} {t}", "%Y-%m-%d %H:%M")
        result.append({"time": t, "available": t not in taken and slot_dt > now})
    return result


def book_appointment(db, settings, user_id, department_id, day_str, time_str, notes_text=""):
    day = parse_date(day_str)
    check_date_allowed(day, settings)
    if time_str not in slot_times(settings):
        raise AppointmentError("Please choose a valid time slot.")
    if datetime.strptime(f"{day_str} {time_str}", "%Y-%m-%d %H:%M") <= datetime.now():
        raise AppointmentError("That time has already passed. Please choose a later slot.")

    try:
        with transaction(db):
            dept = db.execute("SELECT * FROM departments WHERE id = ?", (department_id,)).fetchone()
            if dept is None or not dept["is_active"]:
                raise AppointmentError("That department is not available.")
            if db.execute(
                "SELECT 1 FROM appointments WHERE department_id = ? AND appointment_date = ? "
                "AND appointment_time = ? AND status IN ('booked','confirmed')",
                (department_id, day_str, time_str),
            ).fetchone():
                raise AppointmentError("That time slot is already booked. Please choose another.")
            if db.execute(
                "SELECT 1 FROM appointments WHERE user_id = ? AND appointment_date = ? "
                "AND appointment_time = ? AND status IN ('booked','confirmed')",
                (user_id, day_str, time_str),
            ).fetchone():
                raise AppointmentError("You already have an appointment at that date and time.")
            cur = db.execute(
                "INSERT INTO appointments (user_id, department_id, appointment_date, "
                "appointment_time, notes, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (user_id, department_id, day_str, time_str, notes_text,
                 datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            )
            notes.create(db, user_id,
                         f"Appointment booked at {dept['name']} on {day_str} at {time_str}.")
            return cur.lastrowid
    except sqlite3.IntegrityError:
        # Safety net: the database itself refuses a double-booked slot.
        raise AppointmentError("That time slot is already booked. Please choose another.")


def cancel_by_user(db, appointment_id, user_id):
    with transaction(db):
        appt = db.execute(APPT_SELECT + " WHERE a.id = ?", (appointment_id,)).fetchone()
        if appt is None or appt["user_id"] != user_id:
            raise AppointmentError("Appointment not found.")
        if appt["status"] not in ACTIVE_STATUSES:
            raise AppointmentError("This appointment can no longer be cancelled.")
        db.execute("UPDATE appointments SET status = 'cancelled' WHERE id = ?", (appointment_id,))
        notes.create(db, user_id, f"You cancelled your appointment at {appt['dept_name']} "
                                  f"on {appt['appointment_date']} at {appt['appointment_time']}.")


def set_status(db, appointment_id, new_status):
    """Admin action: confirmed / completed / cancelled."""
    if new_status not in ALL_STATUSES:
        raise AppointmentError("Invalid status.")
    with transaction(db):
        appt = db.execute(APPT_SELECT + " WHERE a.id = ?", (appointment_id,)).fetchone()
        if appt is None:
            raise AppointmentError("Appointment not found.")
        if new_status not in TRANSITIONS.get(appt["status"], set()):
            raise AppointmentError(f"A {appt['status']} appointment cannot be changed to {new_status}.")
        db.execute("UPDATE appointments SET status = ? WHERE id = ?", (new_status, appointment_id))
        notes.create(db, appt["user_id"],
                     f"Your appointment at {appt['dept_name']} on {appt['appointment_date']} at "
                     f"{appt['appointment_time']} is now {new_status}.")


def list_appointments(db, user_id=None, day=None, department_id=None, status=None,
                      upcoming_only=False, limit=300):
    where, params = [], []
    if user_id:
        where.append("a.user_id = ?"); params.append(user_id)
    if day:
        where.append("a.appointment_date = ?"); params.append(day)
    if department_id:
        where.append("a.department_id = ?"); params.append(department_id)
    if status:
        where.append("a.status = ?"); params.append(status)
    if upcoming_only:
        where.append("a.status IN ('booked','confirmed') AND a.appointment_date >= ?")
        params.append(date.today().isoformat())
    sql = APPT_SELECT
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += (" ORDER BY a.appointment_date, a.appointment_time" if upcoming_only
            else " ORDER BY a.appointment_date DESC, a.appointment_time DESC")
    sql += " LIMIT ?"
    params.append(limit)
    return db.execute(sql, params).fetchall()
