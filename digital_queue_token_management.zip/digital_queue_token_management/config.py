"""Application settings. Secrets are read from environment variables (.env file)."""
import os
import secrets
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _bool(name, default=False):
    return os.environ.get(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


def _int(name, default):
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


def _database_path():
    path = Path(os.environ.get("DATABASE_PATH", "queue.db"))
    return str(path if path.is_absolute() else BASE_DIR / path)


def _secret_key():
    """Return (key, came_from_env). The placeholder from .env.example is not accepted."""
    value = os.environ.get("SECRET_KEY", "").strip()
    if value and not value.startswith("replace-this"):
        return value, True
    return secrets.token_hex(32), False


_KEY, _KEY_FROM_ENV = _secret_key()


class Config:
    # If SECRET_KEY is missing we create a random one. Logins then reset
    # every time the server restarts, which is fine for a quick demo.
    SECRET_KEY_FROM_ENV = _KEY_FROM_ENV
    SECRET_KEY = _KEY

    DATABASE = _database_path()

    DEFAULT_AVG_SERVICE_MINUTES = _int("DEFAULT_AVG_SERVICE_MINUTES", 5)
    ALLOW_MULTIPLE_ACTIVE_TOKENS = _bool("ALLOW_MULTIPLE_ACTIVE_TOKENS", False)
    ENFORCE_PASSWORD_CHANGE = _bool("ENFORCE_PASSWORD_CHANGE", False)

    # Appointment slots: every INTERVAL minutes from START up to (not including) END.
    APPOINTMENT_START = "09:00"
    APPOINTMENT_END = "17:00"
    APPOINTMENT_INTERVAL_MINUTES = 30
    APPOINTMENT_MAX_DAYS_AHEAD = 30

    CSRF_ENABLED = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = _bool("SESSION_COOKIE_SECURE", False)
    MAX_CONTENT_LENGTH = 64 * 1024  # forms are tiny; reject anything bigger

    # Used only by init_db.py to create the development admin account.
    ADMIN_NAME = os.environ.get("ADMIN_NAME", "System Admin")
    ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "admin@example.com")
    ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "Admin@12345")
