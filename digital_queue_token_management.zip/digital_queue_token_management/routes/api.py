"""Small JSON endpoints used by the page JavaScript (live updates)."""
from datetime import datetime

from flask import Blueprint, current_app, g, jsonify, request

import validators
from database import get_db
from security import login_required, user_required
from services import appointment_service as appts
from services import notification_service as notes
from services import queue_service as queue

bp = Blueprint("api", __name__, url_prefix="/api")


@bp.route("/queue")
@user_required
def queue_state():
    db = get_db()
    departments = [{
        "id": d["id"], "name": d["name"], "code": d["code"],
        "waiting": d["waiting_count"], "now_serving": d["serving_label"],
        "est_wait": d["new_token_wait"],
    } for d in queue.department_overview(db)]
    token = queue.user_active_token(db, g.user["id"])
    my_token = None
    if token:
        info = queue.queue_info(db, token)
        my_token = {"id": token["id"], "label": queue.label_of(token),
                    "department": token["dept_name"], "status": token["status"],
                    "position": info["position"], "ahead": info["ahead"],
                    "wait_minutes": info["wait_minutes"], "booked_at": token["created_at"]}
    return jsonify(updated=datetime.now().strftime("%H:%M:%S"),
                   departments=departments, my_token=my_token)


@bp.route("/notifications/unread-count")
@login_required
def unread_count():
    return jsonify(count=notes.unread_count(get_db(), g.user["id"]))


@bp.route("/appointment-slots")
@user_required
def appointment_slots():
    department_id = validators.parse_int(request.args.get("department_id"), 1)
    if department_id is None:
        return jsonify(error="Invalid department."), 400
    try:
        slots = appts.slot_status(get_db(), current_app.config, department_id,
                                  request.args.get("date", ""))
    except appts.AppointmentError as exc:
        return jsonify(error=str(exc)), 400
    return jsonify(slots=slots)
