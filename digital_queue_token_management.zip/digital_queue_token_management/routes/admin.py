import sqlite3

from flask import (Blueprint, current_app, flash, redirect, render_template,
                   request, url_for)

import validators
from database import get_db
from security import admin_required, safe_next_url
from services import appointment_service as appts
from services import queue_service as queue

bp = Blueprint("admin", __name__, url_prefix="/admin")


def _back(default_endpoint):
    """Return to the page the admin came from (only if it is a local path)."""
    return redirect(safe_next_url(request.form.get("next"), url_for(default_endpoint)))


@bp.route("/")
@admin_required
def dashboard():
    db = get_db()
    daily = queue.daily_stats(db, 7)
    chart = {"labels": [d["date"][5:] for d in daily],
             "total": [d["total"] for d in daily],
             "completed": [d["completed"] for d in daily],
             "skipped": [d["skipped"] for d in daily],
             "cancelled": [d["cancelled"] for d in daily]}
    return render_template("admin/dashboard.html",
                           summary=queue.admin_summary(db), daily=daily, chart=chart,
                           dept_stats=queue.department_stats(db), today=queue.today())


# ---- Tokens ---------------------------------------------------------------
@bp.route("/tokens")
@admin_required
def tokens():
    db = get_db()
    day = request.args.get("date", queue.today()).strip()     # "" means all dates
    if day and not validators.valid_date(day):
        flash("Invalid date filter ignored.", "warning")
        day = queue.today()
    department_id = validators.parse_int(request.args.get("department_id"), 1)
    status = request.args.get("status", "")
    if status not in queue.ALL_STATUSES:
        status = ""
    q = request.args.get("q", "").strip()[:60]
    return render_template(
        "admin/tokens.html",
        tokens=queue.list_tokens(db, day or None, department_id, status or None, q or None),
        overview=queue.department_overview(db, queue.today(), include_inactive=True),
        departments=db.execute("SELECT id, name FROM departments ORDER BY name").fetchall(),
        statuses=queue.ALL_STATUSES,
        filters={"date": day, "department_id": department_id, "status": status, "q": q})


@bp.route("/tokens/<int:token_id>/status", methods=["POST"])
@admin_required
def token_status(token_id):
    try:
        token = queue.set_status(get_db(), token_id, request.form.get("status", ""))
        flash(f"Token {queue.label_of(token)} is now {token['status']}.", "success")
    except queue.QueueError as exc:
        flash(str(exc), "danger")
    return _back("admin.tokens")


@bp.route("/departments/<int:department_id>/call-next", methods=["POST"])
@admin_required
def call_next(department_id):
    try:
        token = queue.call_next(get_db(), department_id)
        flash(f"Now serving {queue.label_of(token)} ({token['user_name']}).", "success")
    except queue.QueueError as exc:
        flash(str(exc), "warning")
    return _back("admin.tokens")


# ---- Departments ----------------------------------------------------------
@bp.route("/departments")
@admin_required
def departments():
    return render_template(
        "admin/departments.html",
        departments=queue.department_overview(get_db(), include_inactive=True))


def _save_department(department_id=None):
    """Shared by 'new' and 'edit'. Returns (saved?, form_values)."""
    db = get_db()
    clean, errors = validators.validate_department(request.form)
    if not errors:
        dup = db.execute(
            "SELECT 1 FROM departments WHERE (name = ? OR code = ?) AND id != ?",
            (clean["name"], clean["code"], department_id or 0)).fetchone()
        if dup:
            errors.append("Another department already uses that name or code.")
    if not errors:
        try:
            if department_id:
                db.execute(
                    "UPDATE departments SET name=?, code=?, description=?, avg_service_minutes=?, "
                    "is_active=? WHERE id=?",
                    (clean["name"], clean["code"], clean["description"],
                     clean["avg_service_minutes"], clean["is_active"], department_id))
            else:
                db.execute(
                    "INSERT INTO departments (name, code, description, avg_service_minutes, is_active) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (clean["name"], clean["code"], clean["description"],
                     clean["avg_service_minutes"], clean["is_active"]))
            return True, request.form
        except sqlite3.IntegrityError:
            errors.append("Another department already uses that name or code.")
    for message in errors:
        flash(message, "danger")
    return False, request.form


@bp.route("/departments/new", methods=["GET", "POST"])
@admin_required
def department_new():
    form = {"avg_service_minutes": current_app.config["DEFAULT_AVG_SERVICE_MINUTES"], "is_active": "1"}
    if request.method == "POST":
        saved, form = _save_department()
        if saved:
            flash("Department created.", "success")
            return redirect(url_for("admin.departments"))
    return render_template("admin/department_form.html", form=form, department=None)


@bp.route("/departments/<int:department_id>/edit", methods=["GET", "POST"])
@admin_required
def department_edit(department_id):
    db = get_db()
    department = db.execute("SELECT * FROM departments WHERE id = ?", (department_id,)).fetchone()
    if department is None:
        flash("Department not found.", "danger")
        return redirect(url_for("admin.departments"))
    form = dict(department)
    if request.method == "POST":
        saved, form = _save_department(department_id)
        if saved:
            flash("Department updated.", "success")
            return redirect(url_for("admin.departments"))
    return render_template("admin/department_form.html", form=form, department=department)


@bp.route("/departments/<int:department_id>/toggle", methods=["POST"])
@admin_required
def department_toggle(department_id):
    db = get_db()
    row = db.execute("SELECT is_active, name FROM departments WHERE id = ?", (department_id,)).fetchone()
    if row is None:
        flash("Department not found.", "danger")
    else:
        db.execute("UPDATE departments SET is_active = ? WHERE id = ?",
                   (0 if row["is_active"] else 1, department_id))
        flash(f"{row['name']} is now {'inactive' if row['is_active'] else 'active'}.", "success")
    return redirect(url_for("admin.departments"))


# ---- Appointments ---------------------------------------------------------
@bp.route("/appointments")
@admin_required
def appointments():
    db = get_db()
    day = request.args.get("date", "").strip()
    if day and not validators.valid_date(day):
        flash("Invalid date filter ignored.", "warning")
        day = ""
    department_id = validators.parse_int(request.args.get("department_id"), 1)
    status = request.args.get("status", "")
    if status not in appts.ALL_STATUSES:
        status = ""
    return render_template(
        "admin/appointments.html",
        appointments=appts.list_appointments(db, day=day or None, department_id=department_id,
                                             status=status or None),
        departments=db.execute("SELECT id, name FROM departments ORDER BY name").fetchall(),
        statuses=appts.ALL_STATUSES,
        filters={"date": day, "department_id": department_id, "status": status})


@bp.route("/appointments/<int:appointment_id>/status", methods=["POST"])
@admin_required
def appointment_status(appointment_id):
    try:
        appts.set_status(get_db(), appointment_id, request.form.get("status", ""))
        flash("Appointment updated.", "success")
    except appts.AppointmentError as exc:
        flash(str(exc), "danger")
    return _back("admin.appointments")
