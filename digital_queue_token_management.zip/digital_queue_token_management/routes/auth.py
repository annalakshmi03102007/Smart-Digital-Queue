import sqlite3

from flask import (Blueprint, flash, g, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

import validators
from database import get_db
from security import home_for, login_required, safe_next_url

bp = Blueprint("auth", __name__)

# Used so that "unknown email" and "wrong password" take about the same time.
_DUMMY_HASH = generate_password_hash("not-a-real-password")
BAD_LOGIN = "Invalid email or password."


@bp.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(home_for(g.user))
    form = {}
    if request.method == "POST":
        form = request.form
        clean, errors = validators.validate_registration(request.form)
        if not errors:
            db = get_db()
            if db.execute("SELECT 1 FROM users WHERE email = ?", (clean["email"],)).fetchone():
                errors.append("An account with this email already exists.")
            else:
                try:
                    db.execute(
                        "INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'user')",
                        (clean["name"], clean["email"], generate_password_hash(clean["password"])))
                except sqlite3.IntegrityError:
                    errors.append("An account with this email already exists.")
                else:
                    flash("Account created! You can now log in.", "success")
                    return redirect(url_for("auth.login"))
        for message in errors:
            flash(message, "danger")
    return render_template("auth/register.html", form=form)


def _login(role, template):
    if g.user:
        return redirect(home_for(g.user))
    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        row = get_db().execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        ok = check_password_hash(row["password_hash"] if row else _DUMMY_HASH, password)
        if row and ok and row["role"] == role:
            session.clear()                      # drop any old session data
            session["user_id"] = row["id"]
            flash(f"Welcome, {row['name']}!", "success")
            return redirect(safe_next_url(request.args.get("next"), home_for(row)))
        flash(BAD_LOGIN, "danger")
    return render_template(template, email=request.form.get("email", ""))


@bp.route("/login", methods=["GET", "POST"])
def login():
    return _login("user", "auth/login.html")


@bp.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    return _login("admin", "auth/admin_login.html")


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("main.index"))


@bp.route("/account/password", methods=["GET", "POST"])
@login_required
def change_password():
    if request.method == "POST":
        db = get_db()
        row = db.execute("SELECT password_hash FROM users WHERE id = ?", (g.user["id"],)).fetchone()
        current = request.form.get("current_password") or ""
        new = request.form.get("new_password") or ""
        confirm = request.form.get("confirm_password") or ""
        problem = validators.check_password_strength(new)
        if not check_password_hash(row["password_hash"], current):
            flash("Your current password is not correct.", "danger")
        elif problem:
            flash(problem, "danger")
        elif new != confirm:
            flash("New password and confirmation do not match.", "danger")
        elif new == current:
            flash("The new password must be different from the current one.", "danger")
        else:
            db.execute("UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?",
                       (generate_password_hash(new), g.user["id"]))
            flash("Password changed successfully.", "success")
            return redirect(home_for(g.user))
    return render_template("auth/change_password.html")
