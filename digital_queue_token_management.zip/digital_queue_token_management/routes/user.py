from datetime import date, timedelta

from flask import (Blueprint, current_app, flash, g, redirect, render_template,
                   request, url_for)

import validators
from database import get_db
from security import user_required
from services import appointment_service as appts
from services import notification_service as notes
from services import queue_service as queue

bp = Blueprint("user", __name__)


@bp.route("/dashboard")
@user_required
def dashboard():
    db, uid = get_db(), g.user["id"]
    token = queue.user_active_token(db, uid)
    return render_template(
        "user/dashboard.html",
        token=token,
        info=queue.queue_info(db, token) if token else None,
        appointments=appts.list_appointments(db, user_id=uid, upcoming_only=True, limit=3),
        notifications=notes.list_for_user(db, uid, limit=5),
        token_count=db.execute("SELECT COUNT(*) FROM tokens WHERE user_id = ?", (uid,)).fetchone()[0],
        appt_count=db.execute("SELECT COUNT(*) FROM appointments WHERE user_id = ?", (uid,)).fetchone()[0],
    )


@bp.route("/book-token", methods=["GET", "POST"])
@user_required
def book_token():
    db = get_db()
    if request.method == "POST":
        department_id = validators.parse_int(request.form.get("department_id"), 1)
        if department_id is None:
            flash("Please choose a department.", "danger")
        else:
            try:
                token_id = queue.book_token(
                    db, g.user["id"], department_id,
                    allow_multiple=current_app.config["ALLOW_MULTIPLE_ACTIVE_TOKENS"])
            except queue.QueueError as exc:
                flash(str(exc), "danger")
            else:
                token = queue.get_token(db, token_id)
                flash(f"Token {queue.label_of(token)} booked successfully!", "success")
                return redirect(url_for("user.queue_status"))
    return render_template("user/book_token.html",
                           departments=queue.department_overview(db),
                           active=queue.user_active_token(db, g.user["id"]))


@bp.route("/queue")
@user_required
def queue_status():
    db = get_db()
    token = queue.user_active_token(db, g.user["id"])
    return render_template("user/queue_status.html",
                           departments=queue.department_overview(db),
                           token=token,
                           info=queue.queue_info(db, token) if token else None)


@bp.route("/token/<int:token_id>/cancel", methods=["POST"])
@user_required
def cancel_token(token_id):
    try:
        queue.cancel_by_user(get_db(), token_id, g.user["id"])
        flash("Your token was cancelled.", "success")
    except queue.QueueError as exc:
        flash(str(exc), "danger")
    return redirect(url_for("user.dashboard"))


@bp.route("/appointments", methods=["GET", "POST"])
@user_required
def appointments():
    db, settings = get_db(), current_app.config
    form = {}
    if request.method == "POST":
        form = request.form
        department_id = validators.parse_int(request.form.get("department_id"), 1)
        notes_text = (request.form.get("notes") or "").strip()
        if department_id is None:
            flash("Please choose a department.", "danger")
        elif len(notes_text) > 200:
            flash("Notes must be at most 200 characters.", "danger")
        else:
            try:
                appts.book_appointment(db, settings, g.user["id"], department_id,
                                       request.form.get("appointment_date", ""),
                                       request.form.get("appointment_time", ""), notes_text)
            except appts.AppointmentError as exc:
                flash(str(exc), "danger")
            else:
                flash("Appointment booked successfully!", "success")
                return redirect(url_for("user.appointments"))
    today = date.today()
    return render_template(
        "user/appointments.html", form=form,
        departments=db.execute("SELECT * FROM departments WHERE is_active = 1 ORDER BY name").fetchall(),
        slots=appts.slot_times(settings),
        min_date=today.isoformat(),
        max_date=(today + timedelta(days=settings["APPOINTMENT_MAX_DAYS_AHEAD"])).isoformat(),
        my_appointments=appts.list_appointments(db, user_id=g.user["id"], upcoming_only=True))


@bp.route("/appointments/<int:appointment_id>/cancel", methods=["POST"])
@user_required
def cancel_appointment(appointment_id):
    try:
        appts.cancel_by_user(get_db(), appointment_id, g.user["id"])
        flash("Appointment cancelled.", "success")
    except appts.AppointmentError as exc:
        flash(str(exc), "danger")
    return redirect(url_for("user.appointments"))


@bp.route("/history")
@user_required
def history():
    db, uid = get_db(), g.user["id"]
    return render_template("user/history.html",
                           tokens=queue.list_tokens(db, user_id=uid, limit=200),
                           appointments=appts.list_appointments(db, user_id=uid, limit=200),
                           queue=queue)


@bp.route("/notifications")
@user_required
def notifications():
    return render_template("user/notifications.html",
                           notifications=notes.list_for_user(get_db(), g.user["id"]))


@bp.route("/notifications/read", methods=["POST"])
@user_required
def notifications_read():
    notes.mark_all_read(get_db(), g.user["id"])
    flash("All notifications marked as read.", "success")
    return redirect(url_for("user.notifications"))
