from flask import Blueprint, render_template

from database import get_db
from services import queue_service

bp = Blueprint("main", __name__)


@bp.route("/")
def index():
    departments = queue_service.department_overview(get_db())
    return render_template("index.html", departments=departments)
