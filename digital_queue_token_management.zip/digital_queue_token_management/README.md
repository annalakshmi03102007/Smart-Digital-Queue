# QueueEase – Small Digital Queue & Token Management Platform

A college project that lets people **book a queue token online**, **watch the live queue**,
**book appointments** and **receive in-app notifications**. Staff use an **admin panel** to call
the next token and manage departments, tokens and appointments.

**Tech stack:** Python Flask · SQLite · HTML / CSS / JavaScript · Bootstrap 5 · Chart.js
(Bootstrap and Chart.js load from the internet (CDN), so the laptop needs an internet connection
while you demonstrate.)

---

## 1. Architecture in simple words

```
Browser  ──►  Flask routes (routes/)  ──►  Services (services/)  ──►  SQLite (queue.db)
 (HTML,        - auth.py   login/register     - queue_service.py       tables: users, departments,
  Bootstrap,   - user.py   user pages         - appointment_service.py        tokens, appointments,
  JavaScript)  - admin.py  admin pages        - notification_service.py       notifications
               - api.py    JSON for live updates
```

* **Routes** receive the web request, check the person is allowed, validate the form, then call a service.
* **Services** contain the real rules (token numbers, queue position, status changes). They contain no web code, so they are easy to test.
* **Database transactions:** booking uses `BEGIN IMMEDIATE`, so two people clicking at the same time can never get the same token number. The table also has a `UNIQUE (department, day, number)` rule as a second safety net.
* **Live updates:** the Live Queue page asks `/api/queue` every 5 seconds; the notification bell asks every 15 seconds.

### Folder structure

```
digital_queue_token_management/
├── app.py                  Starts the app (create_app) and registers pages
├── config.py               Settings read from environment variables / .env
├── database.py             SQLite connection + transaction helper
├── schema.sql              All CREATE TABLE statements
├── init_db.py              Creates the database, admin account, sample data
├── security.py             CSRF protection, login/admin decorators, safe redirects
├── validators.py           Server-side form validation
├── requirements.txt        Python packages needed (Flask, python-dotenv)
├── .env.example            Template for your private .env file
├── .gitignore
├── README.md
├── routes/
│   ├── main.py             Home page
│   ├── auth.py             Register, login, admin login, logout, change password
│   ├── user.py             Dashboard, book token, live queue, appointments, history, notifications
│   ├── admin.py            Admin dashboard, tokens, departments, appointments
│   └── api.py              JSON endpoints used by JavaScript
├── services/
│   ├── queue_service.py        Token numbers, queue position, waiting time, statuses, statistics
│   ├── appointment_service.py  Slots, booking rules, status changes
│   └── notification_service.py In-app notifications
├── templates/              HTML pages (Jinja2 + Bootstrap)
│   ├── base.html, index.html, error.html, _macros.html
│   ├── auth/   register, login, admin_login, change_password
│   ├── user/   dashboard, book_token, queue_status, appointments, history, notifications
│   └── admin/  dashboard, tokens, departments, department_form, appointments
├── static/
│   ├── css/style.css       Blue-and-white theme
│   ├── js/main.js          Live queue, notifications, slots, chart, confirm boxes
│   └── images/logo.svg
└── tests/                  75 automated tests (Python's built-in unittest)
```

### Rules the system follows

| Rule | How it works |
|---|---|
| Token number | Per department **and** per day, starting at 1: `GEN-001`, `GEN-002`… Numbers of cancelled tokens are never reused. |
| Queue position | `number of WAITING tokens ahead of you + 1`. Cancelled, skipped and completed tokens are not counted. |
| Waiting time | `(people ahead + the person being served now) × average minutes` of that department (set by the admin per department). |
| Duplicate tokens | A user may hold **one active** (waiting/serving) token per day. Set `ALLOW_MULTIPLE_ACTIVE_TOKENS=true` in `.env` to allow more. |
| Cancel | A user can cancel only **their own** token and only while it is **waiting**. |
| Call next | Picks the lowest waiting number, marks it *serving*, and automatically marks the previous *serving* token *completed*. |
| Allowed status changes | waiting → serving / skipped / cancelled · serving → completed / skipped / cancelled · finished tokens are final. |
| Notifications | Booked, your turn, you are next in line, completed, skipped, cancelled (by you or admin), appointment changes. |

---

## 2. Install Python on Windows 11

1. Open <https://www.python.org/downloads/> in Chrome and click **Download Python 3.x** (3.10 or newer; tested on 3.12).
2. Run the installer. **Tick the box “Add python.exe to PATH”** at the bottom of the first screen, then click **Install Now**.
3. Open **PowerShell** (press the Windows key, type `powershell`, press Enter) and check:

```powershell
python --version
```

You should see something like `Python 3.12.x`.

## 3. Open the project in VS Code

1. Install VS Code from <https://code.visualstudio.com/> (if you do not have it).
2. Unzip `digital_queue_token_management.zip` (right-click → **Extract All…**), for example to `C:\Projects\`.
3. In VS Code choose **File → Open Folder…** and select the `digital_queue_token_management` folder.
4. Open the built-in terminal: **Terminal → New Terminal** (it opens inside the project folder).

All commands below are typed in this terminal.

## 4. Create a virtual environment

A virtual environment keeps this project's packages separate from the rest of your computer.

```powershell
python -m venv venv
venv\Scripts\activate
```

Your prompt now starts with `(venv)`. **Do this activate step every time you open a new terminal.**

> If PowerShell says *“running scripts is disabled on this system”*, run this once and try again:
> `Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned`
> (or use the **Command Prompt** terminal and run `venv\Scripts\activate.bat`).

## 5. Install the dependencies

```powershell
pip install -r requirements.txt
```

## 6. Create the `.env` file (your private settings)

```powershell
copy .env.example .env
python -c "import secrets; print(secrets.token_hex(32))"
```

Copy the long text that is printed. Open `.env` in VS Code and replace
`replace-this-with-a-long-random-value` after `SECRET_KEY=` with it. Save the file.

> The `.env` file must never be shared or uploaded to GitHub (`.gitignore` already excludes it).

## 7. Initialise the database (with sample data)

```powershell
python init_db.py --sample-data
```

This creates `queue.db`, the admin account, 4 sample departments, 4 sample users, 3 sample tokens and 1 sample appointment.
(For an empty system without demo data, run `python init_db.py` instead.
To wipe everything and start again: `python init_db.py --reset --sample-data` and type `YES` when asked.)

## 8. The admin account

| | Development value |
|---|---|
| Admin login page | `http://127.0.0.1:5000/admin/login` |
| Email | `admin@example.com` |
| Password | `Admin@12345` |

You can change the email / password **before** running `init_db.py` by editing `ADMIN_EMAIL` and `ADMIN_PASSWORD` in `.env`.
The admin account is created with a **“must change password”** flag, so a warning banner is shown until the password is changed
(menu → **Change password**).

**Before any real-world deployment:** change the admin password, set a real `SECRET_KEY`,
set `ENFORCE_PASSWORD_CHANGE=true` (then the admin cannot use any page until the default password is changed),
use HTTPS with `SESSION_COOKIE_SECURE=true`, and run with a production server (not `python app.py`).

Sample users (all with password `User@12345`): `student@example.com` (no token yet – best for testing),
`alice@example.com`, `bob@example.com`, `carol@example.com`.

## 9. Start the application

```powershell
python app.py
```

## 10. Open it in Chrome

Go to **<http://127.0.0.1:5000>**. Stop the server any time with **Ctrl + C** in the terminal.

---

## 11. Run the automated tests

```powershell
python -m unittest discover -v
```

Expected ending: `Ran 75 tests ... OK`. The tests use a temporary database, so they never touch your real data.

## 12. Demonstration workflow (user + admin together)

Use **two browser windows**: a normal Chrome window for the user and an **Incognito** window (Ctrl+Shift+N) for the admin.

1. **User window:** open `http://127.0.0.1:5000` → **Register** → create your own account → **Login**.
2. Click **Book Token** → choose **General Enquiry** → **Get token**. You land on **Live Queue**: note your token (e.g. `GEN-003`), position (3) and estimated wait (10 min).
3. Try booking a second token → you get the *“already have an active token”* message (duplicate protection).
4. **Admin window:** open `http://127.0.0.1:5000/admin/login` → login as `admin@example.com` / `Admin@12345`.
5. The **Admin dashboard** shows totals, a 7-day chart and today's statistics. Open **Tokens**.
6. Click **Call next token** for *General Enquiry* → `GEN-001` (Alice) is now *serving*.
7. **User window:** within 5 seconds your position drops (3 → 2) without refreshing. Click the **bell** to read notifications.
8. In the admin window click **Call next token** again; then once more → your token becomes **serving** and the page shows *“It is your turn!”*.
9. Admin: on a token row use **Skip**, **Complete** or **Cancel**. Use the filters (date, department, status, search) to find tokens.
10. **Cancel test (user):** book a token with another account (e.g. `student@example.com`), then press **Cancel token** on the dashboard.
11. **Appointment test (user):** open **Appointments** → choose department, a date from tomorrow, a free time → **Book appointment**. Taken slots are greyed out.
12. **Admin:** open **Appointments** → **Confirm** / **Complete** / **Cancel**. The user receives a notification.
13. **Departments (admin):** **Departments → New department** (e.g. *Library*, code `LIB`, 7 minutes). Edit it or **Deactivate** it – it disappears from the user's Book Token page.
14. **Security demo:** while logged in as a normal user, open `http://127.0.0.1:5000/admin/` → you get **403 Access denied**.
15. Show **History** (user) for all past tokens and appointments.

---

## 13. Common errors and solutions

| Problem | Solution |
|---|---|
| `'python' is not recognized…` | Python was installed without PATH. Re-run the installer, choose **Modify/Repair**, and tick **Add python.exe to PATH**. Then open a **new** terminal. |
| `running scripts is disabled on this system` | `Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned`, or use the Command Prompt terminal with `venv\Scripts\activate.bat`. |
| `ModuleNotFoundError: No module named 'flask'` | The virtual environment is not active. Run `venv\Scripts\activate`, then `pip install -r requirements.txt`. |
| Page says *“The database has not been created yet”* / `no such table` | Run `python init_db.py --sample-data`. |
| `Address already in use` / port 5000 busy | Close the other program, or open `app.py`, change `port=5000` to `port=5001` in the last line, and use `http://127.0.0.1:5001`. |
| Page looks plain, no colours or icons | No internet. Bootstrap and Chart.js load from a CDN. Connect to the internet and refresh (Ctrl+F5). |
| I am logged out every time I restart the server | `SECRET_KEY` is not set properly in `.env` (step 6). Set it once and it stays the same. |
| *“Security check failed (CSRF)”* | The page was open too long, or cookies are blocked. Refresh the page (F5) and try again. |
| `database is locked` | Close other programs (e.g. a DB viewer) that have `queue.db` open, then retry. |
| Forgot the admin password (development) | `python init_db.py --reset --sample-data`, type `YES` (this deletes all data). |
| Admin login says “Invalid email or password” | Use `/admin/login` for admins and `/login` for users; the two are separate. |
| Changed `.env` but nothing changed | Stop the server (Ctrl+C) and start it again. |

---

## 14. What was tested (and what was not)

**Tested automatically (75 tests, all passing):** registration and login (including hashed passwords, duplicate emails, bad
input, open-redirect blocking), token generation, sequential numbering (per department and per day), 12 simultaneous bookings
getting unique numbers, queue position and waiting-time calculation, cancelled/skipped handling, token cancellation rules,
calling the next token, status-transition rules, notifications, appointment booking / double-booking / invalid dates and times,
unauthorised admin access (anonymous and normal users), CSRF protection, invalid form inputs (including SQL-injection-style text),
department create/edit/deactivate, admin filters, and that every page renders.

**Also checked by hand:** the real server was started and a full user + admin workflow was run over HTTP with CSRF protection on.
The JavaScript file was syntax-checked.

**NOT tested – please check on your laptop:**
* The look of the pages in Chrome and on a phone (responsive layout), and the Bootstrap / Chart.js CDN files loading.
* The JavaScript behaviour in a real browser: the live 5-second refresh, the greyed-out appointment slots, the notification badge and the chart. (The JSON endpoints they use are tested.)
* Running on Windows 11 itself. The code uses only cross-platform Python and was run on Linux with Python 3.12.

**Known limits (kept simple on purpose):** no email/SMS notifications, no login-attempt lockout, no password-reset by email,
the built-in Flask server is for demonstration only, and "today" means the computer's local date.
