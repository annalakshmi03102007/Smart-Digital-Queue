"""Application entry point.  Start the server with:  python app.py"""
import sqlite3
from datetime import datetime

from flask import Flask, flash, g, redirect, render_template, request, session, url_for

import database
import security
from config import Config
from services import notification_service, queue_service


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)

    if not app.config.get("TESTING") and not Config.SECRET_KEY_FROM_ENV:
        print("WARNING: SECRET_KEY is not set. Using a temporary random key "
              "(logins reset on restart). See README step 'Create the .env file'.")

    app.teardown_appcontext(database.close_db)
    app.jinja_env.globals["csrf_token"] = security.generate_csrf_token
    app.jinja_env.filters["token_label"] = lambda row: queue_service.label_of(row)
    app.jinja_env.filters["nice_dt"] = _nice(
        "%Y-%m-%d %H:%M:%S", "%d %b %Y, %I:%M %p")
    app.jinja_env.filters["nice_date"] = _nice("%Y-%m-%d", "%d %b %Y")
    app.jinja_env.filters["nice_time"] = _nice("%H:%M", "%I:%M %p")

    @app.before_request
    def load_user_and_check_csrf():
        g.user = None
        user_id = session.get("user_id")
        if user_id is not None and request.endpoint != "static":
            g.user = database.get_db().execute(
                "SELECT id, name, email, role, must_change_password FROM users WHERE id = ?",
                (user_id,),
            ).fetchone()
            if g.user is None:          # account was deleted
                session.clear()
        security.check_csrf()

        if (g.user is not None and g.user["must_change_password"]
                and app.config["ENFORCE_PASSWORD_CHANGE"]
                and request.endpoint not in ("auth.change_password", "auth.logout", "static")):
            flash("You must change the default password before continuing.", "warning")
            return redirect(url_for("auth.change_password"))

    @app.context_processor
    def inject_globals():
        unread = 0
        if g.get("user") is not None:
            unread = notification_service.unread_count(database.get_db(), g.user["id"])
        return {"current_user": g.get("user"), "unread_count": unread}

    from routes import admin, api, auth, main, user
    for module in (main, auth, user, admin, api):
        app.register_blueprint(module.bp)

    @app.errorhandler(400)
    def bad_request(error):
        return render_template("error.html", code=400, title="Bad request",
                               message=getattr(error, "description", "Bad request.")), 400

    @app.errorhandler(403)
    def forbidden(error):
        return render_template("error.html", code=403, title="Access denied",
                               message="You do not have permission to view this page."), 403

    @app.errorhandler(404)
    def not_found(error):
        return render_template("error.html", code=404, title="Page not found",
                               message="The page you are looking for does not exist."), 404

    @app.errorhandler(413)
    def too_large(error):
        return render_template("error.html", code=413, title="Request too large",
                               message="The submitted data was too large."), 413

    @app.errorhandler(sqlite3.Error)
    def database_error(error):
        app.logger.exception("Database error")
        if "no such table" in str(error).lower():
            message = ("The database has not been created yet. Stop the server and run: "
                       "python init_db.py --sample-data")
        else:
            message = "A database problem occurred. Please try again."
        return render_template("error.html", code=500, title="Database problem",
                               message=message), 500

    @app.errorhandler(500)
    def server_error(error):
        return render_template("error.html", code=500, title="Something went wrong",
                               message="An unexpected error occurred. Please try again."), 500

    return app


def _nice(source_format, target_format):
    def convert(value):
        if not value:
            return "—"
        try:
            return datetime.strptime(value, source_format).strftime(target_format)
        except ValueError:
            return value
    return convert


if __name__ == "__main__":
    # debug=False is safer; set FLASK_DEBUG=1 yourself if you want auto-reload while coding.
    create_app().run(host="127.0.0.1", port=5000, debug=False)
