"""CSRF protection, login / role decorators and safe redirects."""
import functools
import hmac
import secrets

from flask import abort, current_app, flash, g, jsonify, redirect, request, session, url_for


# ---- CSRF -----------------------------------------------------------------
def generate_csrf_token():
    """One random token per login session; every form carries it as a hidden field."""
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


def check_csrf():
    """Reject any POST/PUT/PATCH/DELETE that does not carry the right token."""
    if not current_app.config["CSRF_ENABLED"]:
        return
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        sent = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token", "")
        expected = session.get("_csrf", "")
        if not expected or not hmac.compare_digest(sent, expected):
            abort(400, "Security check failed (missing or invalid CSRF token). "
                       "Please go back, refresh the page and try again.")


# ---- Roles ----------------------------------------------------------------
def home_for(user):
    return url_for("admin.dashboard") if user["role"] == "admin" else url_for("user.dashboard")


def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            if request.path.startswith("/api/"):
                return jsonify(error="Login required."), 401
            flash("Please log in to continue.", "warning")
            return redirect(url_for("auth.login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def user_required(view):
    """Normal users only. Admins are sent to their own dashboard."""
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            if request.path.startswith("/api/"):
                return jsonify(error="Login required."), 401
            flash("Please log in to continue.", "warning")
            return redirect(url_for("auth.login", next=request.path))
        if g.user["role"] != "user":
            if request.path.startswith("/api/"):
                return jsonify(error="Forbidden."), 403
            return redirect(url_for("admin.dashboard"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    """Admins only. Anonymous visitors go to the admin login; other users get 403."""
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            flash("Please log in as an administrator.", "warning")
            return redirect(url_for("auth.admin_login"))
        if g.user["role"] != "admin":
            abort(403)
        return view(*args, **kwargs)
    return wrapped


def safe_next_url(target, default):
    """Only allow redirects to paths on THIS site (blocks open-redirect tricks)."""
    if target and target.startswith("/") and not target.startswith("//") and "\\" not in target:
        return target
    return default
