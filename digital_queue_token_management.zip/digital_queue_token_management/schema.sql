-- SQLite schema for the Digital Queue & Token Management Platform.
-- Timestamps are stored as local-time text: 'YYYY-MM-DD HH:MM:SS'.

CREATE TABLE IF NOT EXISTS users (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    name                 TEXT    NOT NULL CHECK (length(name) BETWEEN 2 AND 80),
    email                TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    password_hash        TEXT    NOT NULL,
    role                 TEXT    NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
    must_change_password INTEGER NOT NULL DEFAULT 0 CHECK (must_change_password IN (0, 1)),
    created_at           TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS departments (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    name                TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    code                TEXT    NOT NULL UNIQUE COLLATE NOCASE
                                CHECK (length(code) BETWEEN 2 AND 4),   -- token prefix, e.g. GEN
    description         TEXT    NOT NULL DEFAULT '',
    avg_service_minutes INTEGER NOT NULL DEFAULT 5
                                CHECK (avg_service_minutes BETWEEN 1 AND 120),
    is_active           INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    created_at          TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS tokens (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id INTEGER NOT NULL REFERENCES departments(id) ON DELETE RESTRICT,
    service_date  TEXT    NOT NULL,                      -- 'YYYY-MM-DD'
    token_number  INTEGER NOT NULL CHECK (token_number > 0),
    status        TEXT    NOT NULL DEFAULT 'waiting'
                          CHECK (status IN ('waiting','serving','completed','skipped','cancelled')),
    next_notified INTEGER NOT NULL DEFAULT 0 CHECK (next_notified IN (0, 1)),
    created_at    TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    called_at     TEXT,
    finished_at   TEXT,
    -- A token number can never repeat inside one department on one day.
    UNIQUE (department_id, service_date, token_number)
);
CREATE INDEX IF NOT EXISTS ix_tokens_queue ON tokens (department_id, service_date, status);
CREATE INDEX IF NOT EXISTS ix_tokens_user  ON tokens (user_id, service_date);

CREATE TABLE IF NOT EXISTS appointments (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id    INTEGER NOT NULL REFERENCES departments(id) ON DELETE RESTRICT,
    appointment_date TEXT    NOT NULL,                   -- 'YYYY-MM-DD'
    appointment_time TEXT    NOT NULL,                   -- 'HH:MM'
    status           TEXT    NOT NULL DEFAULT 'booked'
                             CHECK (status IN ('booked','confirmed','completed','cancelled')),
    notes            TEXT    NOT NULL DEFAULT '',
    created_at       TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
-- Only one ACTIVE appointment per department, date and time slot.
CREATE UNIQUE INDEX IF NOT EXISTS ux_appointment_slot
    ON appointments (department_id, appointment_date, appointment_time)
    WHERE status IN ('booked', 'confirmed');
CREATE INDEX IF NOT EXISTS ix_appointments_user ON appointments (user_id, appointment_date);

CREATE TABLE IF NOT EXISTS notifications (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    message    TEXT    NOT NULL,
    is_read    INTEGER NOT NULL DEFAULT 0 CHECK (is_read IN (0, 1)),
    created_at TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS ix_notifications_user ON notifications (user_id, is_read);
