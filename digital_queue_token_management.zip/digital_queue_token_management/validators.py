"""Server-side form validation. Every function returns (clean_values, errors)."""
import re
from datetime import datetime

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
CODE_RE = re.compile(r"^[A-Z]{2,4}$")


def parse_int(value, minimum=None, maximum=None):
    """Return an int, or None if the text is not a valid whole number in range."""
    try:
        number = int(str(value).strip())
    except (TypeError, ValueError):
        return None
    if minimum is not None and number < minimum:
        return None
    if maximum is not None and number > maximum:
        return None
    return number


def valid_date(value):
    try:
        datetime.strptime(value or "", "%Y-%m-%d")
        return True
    except ValueError:
        return False


def check_password_strength(password):
    if len(password) < 8:
        return "Password must be at least 8 characters long."
    if len(password) > 128:
        return "Password must be at most 128 characters long."
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        return "Password must contain at least one letter and one number."
    return None


def validate_registration(form):
    errors = []
    name = " ".join((form.get("name") or "").split())
    email = (form.get("email") or "").strip().lower()
    password = form.get("password") or ""
    confirm = form.get("confirm_password") or ""

    if not 2 <= len(name) <= 80:
        errors.append("Name must be between 2 and 80 characters.")
    if len(email) > 120 or not EMAIL_RE.match(email):
        errors.append("Please enter a valid email address.")
    problem = check_password_strength(password)
    if problem:
        errors.append(problem)
    elif password != confirm:
        errors.append("Password and confirmation do not match.")
    return {"name": name, "email": email, "password": password}, errors


def validate_department(form):
    errors = []
    name = " ".join((form.get("name") or "").split())
    code = (form.get("code") or "").strip().upper()
    description = (form.get("description") or "").strip()
    minutes = parse_int(form.get("avg_service_minutes"), 1, 120)

    if not 2 <= len(name) <= 60:
        errors.append("Department name must be between 2 and 60 characters.")
    if not CODE_RE.match(code):
        errors.append("Code must be 2 to 4 capital letters (for example GEN).")
    if len(description) > 200:
        errors.append("Description must be at most 200 characters.")
    if minutes is None:
        errors.append("Average service time must be a whole number from 1 to 120 minutes.")
    return {"name": name, "code": code, "description": description,
            "avg_service_minutes": minutes,
            "is_active": 1 if form.get("is_active") else 0}, errors
