"""SQLite helpers: connection per request, schema creation and transactions."""
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from flask import current_app, g

SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"


def connect(path):
    """Open a SQLite connection.

    isolation_level=None means Python does not start transactions by itself;
    we start them explicitly with transaction() below.
    """
    conn = sqlite3.connect(path, timeout=10, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def get_db():
    if "db" not in g:
        g.db = connect(current_app.config["DATABASE"])
    return g.db


def close_db(error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_schema(conn):
    """Create all tables (safe to run many times)."""
    conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))


@contextmanager
def transaction(db):
    """Run a block as ONE all-or-nothing database transaction.

    BEGIN IMMEDIATE locks the database for writing straight away, so two people
    booking at the same moment cannot receive the same token number.
    """
    db.execute("BEGIN IMMEDIATE")
    try:
        yield db
    except BaseException:
        db.execute("ROLLBACK")
        raise
    else:
        db.execute("COMMIT")
