// Small helper scripts: confirmations, live notification badge,
// live queue board, appointment slots and the admin chart.
(function () {
  "use strict";

  const STATUS_CLASS = {
    waiting: "text-bg-warning", serving: "text-bg-primary", completed: "text-bg-success",
    skipped: "text-bg-secondary", cancelled: "text-bg-danger",
  };

  function esc(value) {            // stop text from being treated as HTML
    const div = document.createElement("div");
    div.textContent = value === null || value === undefined ? "" : String(value);
    return div.innerHTML;
  }

  async function getJSON(url) {
    const response = await fetch(url, { headers: { Accept: "application/json" }, credentials: "same-origin" });
    if (!response.ok) throw new Error("HTTP " + response.status);
    return response.json();
  }

  document.addEventListener("DOMContentLoaded", function () {
    // 1. "Are you sure?" on forms that carry data-confirm="..."
    document.querySelectorAll("form[data-confirm]").forEach(function (form) {
      form.addEventListener("submit", function (event) {
        if (!window.confirm(form.dataset.confirm)) event.preventDefault();
      });
    });

    // 2. Notification badge refreshes every 15 seconds
    const badge = document.getElementById("notif-badge");
    if (badge) {
      setInterval(async function () {
        try {
          const data = await getJSON("/api/notifications/unread-count");
          badge.textContent = data.count;
          badge.classList.toggle("d-none", data.count === 0);
        } catch (e) { /* ignore temporary network problems */ }
      }, 15000);
    }

    // 3. Live queue board (refreshes every 5 seconds)
    const live = document.getElementById("live-queue");
    if (live) {
      let lastStatus = live.dataset.status || "";
      const myBox = document.getElementById("my-token-box");
      const board = document.getElementById("department-board");
      const stamp = document.getElementById("last-updated");

      function renderMyToken(t) {
        if (!t) {
          myBox.innerHTML = '<p class="mb-2 text-muted">You have no active token today.</p>' +
            '<a class="btn btn-primary" href="/book-token">Book a token</a>';
          return;
        }
        const cancel = t.status === "waiting"
          ? '<form method="post" action="/token/' + t.id + '/cancel" data-confirm="Cancel this token?" class="mt-3">' +
            '<input type="hidden" name="csrf_token" value="' + esc(live.dataset.csrf) + '">' +
            '<button class="btn btn-outline-danger btn-sm">Cancel token</button></form>' : "";
        const turn = t.status === "serving"
          ? '<div class="alert alert-success mt-3 mb-0">It is your turn! Please go to the counter.</div>'
          : '<div class="row text-center mt-3"><div class="col-6"><div class="stat-label text-muted">Queue position</div>' +
            '<div class="fs-2 fw-bold text-primary">' + esc(t.position) + '</div></div>' +
            '<div class="col-6"><div class="stat-label text-muted">Estimated wait</div>' +
            '<div class="fs-2 fw-bold text-primary">' + esc(t.wait_minutes) + ' min</div></div></div>';
        myBox.innerHTML =
          '<div class="text-muted small">' + esc(t.department) + '</div>' +
          '<div class="token-number">' + esc(t.label) + '</div>' +
          '<span class="badge status-badge ' + (STATUS_CLASS[t.status] || "text-bg-light") + ' mt-2">' +
          esc(t.status) + '</span>' + turn + cancel;
        // forms created here also need the confirm prompt
        myBox.querySelectorAll("form[data-confirm]").forEach(function (form) {
          form.addEventListener("submit", function (ev) {
            if (!window.confirm(form.dataset.confirm)) ev.preventDefault();
          });
        });
      }

      function renderBoard(departments) {
        board.innerHTML = departments.map(function (d) {
          return '<div class="col-12 col-md-6 col-xl-4"><div class="card h-100"><div class="card-body">' +
            '<div class="d-flex justify-content-between"><h5 class="mb-1">' + esc(d.name) + '</h5>' +
            '<span class="badge text-bg-light">' + esc(d.code) + '</span></div>' +
            '<div class="text-muted small">Now serving</div>' +
            '<div class="now-serving">' + (d.now_serving ? esc(d.now_serving) : "—") + '</div>' +
            '<div class="mt-2 small">Waiting: <strong>' + esc(d.waiting) + '</strong> &nbsp;|&nbsp; ' +
            'Wait for a new token: <strong>' + esc(d.est_wait) + ' min</strong></div>' +
            '</div></div></div>';
        }).join("");
      }

      async function refresh() {
        try {
          const data = await getJSON("/api/queue");
          renderBoard(data.departments);
          renderMyToken(data.my_token);
          const newStatus = data.my_token ? data.my_token.status : "none";
          if (lastStatus && lastStatus !== newStatus) {
            const flash = document.getElementById("live-flash");
            if (flash) {
              flash.className = "alert alert-info";
              flash.textContent = "Your token status changed. Check your notifications.";
            }
          }
          lastStatus = newStatus;
          if (stamp) stamp.textContent = data.updated;
        } catch (e) {
          if (stamp) stamp.textContent = "connection problem – retrying…";
        }
      }
      setInterval(refresh, 5000);
    }

    // 4. Appointment time slots: grey out taken or past slots
    const apptForm = document.getElementById("appointment-form");
    if (apptForm) {
      const dept = apptForm.querySelector("[name=department_id]");
      const day = apptForm.querySelector("[name=appointment_date]");
      const time = apptForm.querySelector("[name=appointment_time]");
      const hint = document.getElementById("slot-hint");
      async function loadSlots() {
        if (!dept.value || !day.value) return;
        try {
          const data = await getJSON("/api/appointment-slots?department_id=" +
            encodeURIComponent(dept.value) + "&date=" + encodeURIComponent(day.value));
          const wanted = time.value;
          time.innerHTML = '<option value="">Choose a time…</option>' + data.slots.map(function (s) {
            return '<option value="' + esc(s.time) + '"' + (s.available ? "" : " disabled") + '>' +
              esc(s.time) + (s.available ? "" : " (unavailable)") + '</option>';
          }).join("");
          time.value = wanted;
          if (hint) hint.textContent = "";
        } catch (e) { if (hint) hint.textContent = "Could not load slots; the server will check your choice."; }
      }
      dept.addEventListener("change", loadSlots);
      day.addEventListener("change", loadSlots);
    }

    // 5. Admin dashboard chart (Chart.js is loaded from a CDN)
    const canvas = document.getElementById("dailyChart");
    const dataTag = document.getElementById("chart-data");
    if (canvas && dataTag && window.Chart) {
      const d = JSON.parse(dataTag.textContent);
      new Chart(canvas, {
        type: "bar",
        data: {
          labels: d.labels,
          datasets: [
            { label: "Total", data: d.total, backgroundColor: "#0d6efd" },
            { label: "Completed", data: d.completed, backgroundColor: "#198754" },
            { label: "Skipped", data: d.skipped, backgroundColor: "#6c757d" },
            { label: "Cancelled", data: d.cancelled, backgroundColor: "#dc3545" },
          ],
        },
        options: { responsive: true, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } },
      });
    }
  });
})();
