"""Create the database, the development admin account and (optionally) sample data.

Usage (from the project folder, with the virtual environment active):
    python init_db.py                 -> tables + admin account
    python init_db.py --sample-data   -> also add demo departments, users, tokens
    python init_db.py --reset         -> DELETE the database file first (asks to confirm)
"""
import argparse
import os
import sys
from datetime import date, timedelta

from werkzeug.security import generate_password_hash

import database
from config import Config
from services import appointment_service, queue_service

SAMPLE_PASSWORD = "User@12345"


def create_admin(conn):
    existing = conn.execute("SELECT id FROM users WHERE email = ?", (Config.ADMIN_EMAIL,)).fetchone()
    if existing:
        print(f"  Admin account already exists: {Config.ADMIN_EMAIL}")
        return False
    conn.execute(
        "INSERT INTO users (name, email, password_hash, role, must_change_password) "
        "VALUES (?, ?, ?, 'admin', 1)",
        (Config.ADMIN_NAME, Config.ADMIN_EMAIL.lower(), generate_password_hash(Config.ADMIN_PASSWORD)),
    )
    print(f"  Admin account created: {Config.ADMIN_EMAIL}")
    return True


def add_sample_data(conn):
    departments = [
        ("General Enquiry", "GEN", "Questions and general information", 5),
        ("Billing Counter", "BIL", "Payments, invoices and refunds", 8),
        ("Document Verification", "DOC", "Submit and verify your documents", 10),
        ("Customer Support", "SUP", "Complaints and technical help", 6),
    ]
    for name, code, desc, minutes in departments:
        conn.execute(
            "INSERT OR IGNORE INTO departments (name, code, description, avg_service_minutes) "
            "VALUES (?, ?, ?, ?)", (name, code, desc, minutes))

    pw = generate_password_hash(SAMPLE_PASSWORD)
    for name, email in [("Student Demo", "student@example.com"), ("Alice Kumar", "alice@example.com"),
                        ("Bob Raj", "bob@example.com"), ("Carol Devi", "carol@example.com")]:
        conn.execute("INSERT OR IGNORE INTO users (name, email, password_hash, role) "
                     "VALUES (?, ?, ?, 'user')", (name, email, pw))

    def uid(email):
        return conn.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()[0]

    def did(code):
        return conn.execute("SELECT id FROM departments WHERE code = ?", (code,)).fetchone()[0]

    today = queue_service.today()
    already = conn.execute("SELECT COUNT(*) FROM tokens WHERE service_date = ?", (today,)).fetchone()[0]
    if already == 0:
        for email, code in [("alice@example.com", "GEN"), ("bob@example.com", "GEN"),
                            ("carol@example.com", "BIL")]:
            queue_service.book_token(conn, uid(email), did(code))

    tomorrow = (date.today() + timedelta(days=1)).isoformat()
    if conn.execute("SELECT COUNT(*) FROM appointments").fetchone()[0] == 0:
        try:
            appointment_service.book_appointment(
                conn, vars(Config), uid("alice@example.com"), did("SUP"), tomorrow, "10:00",
                "Router problem")
        except appointment_service.AppointmentError as exc:
            print("  (sample appointment skipped:", exc, ")")
    print("  Sample departments, users, tokens and an appointment added.")


def main():
    parser = argparse.ArgumentParser(description="Initialise the queue database.")
    parser.add_argument("--sample-data", action="store_true", help="add demo data")
    parser.add_argument("--reset", action="store_true", help="delete the existing database first")
    args = parser.parse_args()

    path = Config.DATABASE
    if args.reset and os.path.exists(path):
        if input(f"This will DELETE {path}. Type YES to continue: ").strip() != "YES":
            print("Cancelled.")
            return 1
        os.remove(path)
        print("  Old database deleted.")

    conn = database.connect(path)
    try:
        database.init_schema(conn)
        print(f"Database ready: {path}")
        create_admin(conn)
        if args.sample_data:
            add_sample_data(conn)
    finally:
        conn.close()

    print("\nDevelopment login details (change before real use!):")
    print(f"  Admin : {Config.ADMIN_EMAIL}  /  {Config.ADMIN_PASSWORD}")
    if args.sample_data:
        print(f"  Users : student@example.com, alice@example.com, bob@example.com, "
              f"carol@example.com  /  {SAMPLE_PASSWORD}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
